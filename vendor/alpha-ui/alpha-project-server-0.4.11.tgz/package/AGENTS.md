# Alpha's UI project server

Правила UI: `node_modules/@alpha/core/AGENTS.md` относительно корня подключённого приложения. Не передавай сборочные команды через HTTP. Проект сам определяет команду сборки в `alpha.project.json`. При отсутствии компонента сообщи пользователю и создай или обнови `ui-unspec/<component_name>.md` в приложении.
