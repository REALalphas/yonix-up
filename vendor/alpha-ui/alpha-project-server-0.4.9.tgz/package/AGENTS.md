# Alpha UI project server

Правила UI: `node_modules/@alpha/core/AGENTS.md`. Не передавай сборочные команды через HTTP. Проект сам определяет команду сборки в `alpha.project.json`. При отсутствии компонента сообщи пользователю и запиши конкретный пробел в `ALPHA_UI_GAPS.md`.
