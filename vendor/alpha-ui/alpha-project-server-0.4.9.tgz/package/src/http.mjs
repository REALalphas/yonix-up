import { readFile, stat } from 'node:fs/promises';
import { resolve, sep, extname } from 'node:path';

export const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.woff2':'font/woff2','.tgz':'application/octet-stream','.md':'text/markdown; charset=utf-8'};
export function json(res,status,value) { res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'}); res.end(JSON.stringify(value)); }
export async function body(req) {
  let text=''; for await (const chunk of req) { text+=chunk; if(text.length>65536) throw new Error('Слишком большой запрос'); }
  return JSON.parse(text||'{}');
}
export function within(root,path) { const base=resolve(root),target=resolve(base,path); if(target!==base&&!target.startsWith(base+sep)) throw new Error('Недопустимый путь'); return target; }
export function webUrl(value) { const url=new URL(value); if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.hash) throw new Error('Нужен HTTP(S) URL без логина и пароля'); return url; }
export function allowMutation(req, token) {
  if(req.headers.origin && req.headers.origin !== `http://${req.headers.host}` && req.headers.origin !== `https://${req.headers.host}`) return false;
  if(token && req.headers.authorization !== `Bearer ${token}`) return false;
  return true;
}
export async function staticFile(req,res,root,path,{spa=false}={}) {
  let file=within(root,decodeURIComponent(path));
  try { if((await stat(file)).isDirectory()) file=within(file,'index.html'); } catch { if(spa&&!extname(path)) file=within(root,'index.html'); }
  try {
    const bytes=await readFile(file);
    res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream','Cache-Control':extname(file)==='.html'?'no-store':'public, max-age=31536000, immutable'});
    res.end(req.method==='HEAD'?undefined:bytes);
  } catch { json(res,404,{error:'Файл не найден'}); }
}
