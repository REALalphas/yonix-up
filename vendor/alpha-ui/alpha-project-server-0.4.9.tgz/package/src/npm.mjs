import { spawn, execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
export function npmCli() {
  if(process.env.npm_execpath?.endsWith('.js')) return process.env.npm_execpath;
  const candidates=[join(dirname(process.execPath),'node_modules/npm/bin/npm-cli.js')];
  try { candidates.push(...execFileSync(process.platform==='win32'?'where.exe':'which',['npm'],{encoding:'utf8'}).trim().split(/\r?\n/).map(p=>join(dirname(p),'node_modules/npm/bin/npm-cli.js'))); } catch {}
  const path=candidates.find(existsSync); if(!path) throw new Error('Запусти alpha-project через npm run.'); return path;
}
export function runNpm(args, {cwd,env=process.env,onOutput=()=>{}}={}) {
  return new Promise((resolve,reject)=>{
    const child=spawn(process.execPath,[npmCli(),...args],{cwd,env,shell:false,windowsHide:true,stdio:['ignore','pipe','pipe']});
    let log=''; const collect=b=>{log=(log+String(b)).slice(-12000);onOutput(String(b));};
    child.stdout.on('data',collect);child.stderr.on('data',collect);
    const timer=setTimeout(()=>{child.kill();reject(new Error('Сборка превысила 10 минут'));},600000);
    child.once('error',e=>{clearTimeout(timer);reject(e);});child.once('exit',code=>{clearTimeout(timer);code===0?resolve(log):reject(new Error(log||`npm завершился с кодом ${code}`));});
  });
}
