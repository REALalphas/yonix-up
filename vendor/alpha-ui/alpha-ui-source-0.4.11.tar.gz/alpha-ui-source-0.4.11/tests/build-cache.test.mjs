import test from 'node:test';
import assert from 'node:assert/strict';
import {
  mkdtemp,
  mkdir,
  writeFile,
  readFile,
  readdir,
  rm,
  utimes,
  symlink,
} from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { cleanBuildCache } from '../packages/project-server/src/build-cache.mjs';
import { createProjectServer } from '../packages/project-server/src/server.mjs';

const id = (number) => `0.4.${number}-00000000-0000-4000-8000-${String(number).padStart(12, '0')}`;
async function fixture(t) {
  const source = await mkdtemp(join(tmpdir(), 'alpha-cache-test-'));
  t.after(() => rm(source, { recursive: true, force: true }));
  const builds = join(source, '.alpha-builds');
  await mkdir(builds);
  return { source, builds };
}
async function build(builds, number, output = 'dist') {
  const dir = join(builds, id(number), output);
  await mkdir(dir, { recursive: true });
  const index = join(dir, 'index.html');
  await writeFile(index, String(number));
  await utimes(index, new Date(number * 1000), new Date(number * 1000));
}

test('cleanup keeps active even when oldest, retains two newest builds, removes incomplete runs, leaves foreign entries', async (t) => {
  const { builds } = await fixture(t);
  for (let number = 1; number <= 6; number++) await build(builds, number);
  await mkdir(join(builds, id(7)));
  await mkdir(join(builds, 'user-backup'));
  await writeFile(join(builds, 'active.json'), JSON.stringify({ id: id(1) }));
  const result = await cleanBuildCache({ builds, activeId: id(1) });
  assert.deepEqual(new Set(result.kept), new Set([id(1), id(6), id(5)]));
  assert.deepEqual(new Set(result.removed), new Set([id(2), id(3), id(4), id(7)]));
  assert.ok((await readdir(builds)).includes('user-backup'));
  assert.equal(JSON.parse(await readFile(join(builds, 'active.json'))).id, id(1));
});

test('dry run, custom nested output, retainBuilds=1 and symlink safety', async (t) => {
  const { source, builds } = await fixture(t);
  await build(builds, 1, 'web/output');
  await build(builds, 2, 'web/output');
  const external = join(source, 'external');
  await mkdir(external);
  await writeFile(join(external, 'keep.txt'), 'keep');
  await symlink(external, join(builds, id(3)), process.platform === 'win32' ? 'junction' : 'dir');
  const preview = await cleanBuildCache({
    builds,
    output: 'web/output',
    activeId: id(1),
    retainBuilds: 1,
    dryRun: true,
  });
  assert.deepEqual(preview.removed, [id(2)]);
  assert.ok((await readdir(builds)).includes(id(2)));
  await cleanBuildCache({ builds, output: 'web/output', activeId: id(1), retainBuilds: 1 });
  assert.equal(await readFile(join(external, 'keep.txt'), 'utf8'), 'keep');
  assert.ok((await readdir(builds)).includes(id(3)));
  await assert.rejects(cleanBuildCache({ builds, retainBuilds: 0 }), /retainBuilds/);
});

test('server startup actually prunes old runs and continues serving active and retained lazy assets', async (t) => {
  const { source, builds } = await fixture(t);
  for (let number = 1; number <= 4; number++) await build(builds, number);
  const pointer = JSON.stringify({ id: id(1), version: '0.4.1' });
  await writeFile(join(builds, 'active.json'), pointer);
  await writeFile(join(builds, id(4), 'dist/lazy.js'), 'export const alive=true;');
  const project = await createProjectServer({ source, framework: 'qwik', retainBuilds: 2 });
  await new Promise((resolve) => project.server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise((resolve) => project.server.close(resolve)));
  const base = `http://127.0.0.1:${project.server.address().port}`;
  assert.equal(await (await fetch(base + `/runs/${id(1)}/`)).text(), '1');
  assert.match(await (await fetch(base + `/runs/${id(4)}/lazy.js`)).text(), /alive/);
  assert.equal((await fetch(base + `/runs/${id(2)}/`)).status, 404);
  assert.equal(await readFile(join(builds, 'active.json'), 'utf8'), pointer);
  assert.equal(project.state().cleanupError, null);
});

test('partial transfer without dist still protects the directory referenced by active.json', async (t) => {
  const { source, builds } = await fixture(t);
  await mkdir(join(builds, id(1)));
  await mkdir(join(builds, id(2)));
  await writeFile(join(builds, 'active.json'), JSON.stringify({ id: id(1), version: '0.4.1' }));
  const project = await createProjectServer({ source, framework: 'react' });
  assert.ok((await readdir(builds)).includes(id(1)));
  assert.ok(!(await readdir(builds)).includes(id(2)));
  assert.equal(project.state().active, null, 'incomplete build must not be advertised as ready');
});
