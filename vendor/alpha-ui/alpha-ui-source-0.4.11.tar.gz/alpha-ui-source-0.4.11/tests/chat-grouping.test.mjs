import test from 'node:test';
import assert from 'node:assert/strict';
import { getChatGroups } from '../packages/core/dist/index.js';
test('chat groups include exactly 30 seconds and close after a larger gap', () => {
  assert.deepEqual(
    getChatGroups([
      { timestamp: 0 },
      { timestamp: 20000 },
      { timestamp: 50000 },
      { timestamp: 80001 },
    ]),
    [
      { start: true, end: false },
      { start: false, end: false },
      { start: false, end: true },
      { start: true, end: true },
    ],
  );
});
test('author, direction, unknown timestamp and reversed time break groups', () => {
  for (const pair of [
    [
      { timestamp: 0, author: 'a' },
      { timestamp: 1, author: 'b' },
    ],
    [{ timestamp: 0 }, { timestamp: 1, outgoing: true }],
    [{}, { timestamp: 1 }],
    [{ timestamp: 2 }, { timestamp: 1 }],
  ])
    assert.deepEqual(getChatGroups(pair), [
      { start: true, end: true },
      { start: true, end: true },
    ]);
});
