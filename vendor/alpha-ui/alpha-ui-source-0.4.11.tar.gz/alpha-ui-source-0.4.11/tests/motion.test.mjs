import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { transitionView } from '../packages/core/dist/index.js';
test('duration and easing are independent motion tokens', async () => {
  const { motion } = JSON.parse(await readFile('packages/core/src/tokens.json'));
  assert.deepEqual(motion, {
    hoverDelay: '0.033s',
    interaction: '0.166s',
    fast: '0.4s',
    normal: '0.6s',
    switch: 'cubic-bezier(.5,.4,0,1)',
    transition: 'cubic-bezier(.2,.66,0,1)',
    universal: 'cubic-bezier(.1,.66,.8,.7)',
    loadingDashes: '2.4s',
  });
});
test('SSR, unsupported browsers and reduced motion commit without snapshots', async () => {
  let calls = 0,
    snapshots = 0;
  const update = () => {
    calls++;
  };
  await transitionView(update, { document: null });
  await transitionView(update, { document: {} });
  await transitionView(update, {
    document: {
      startViewTransition() {
        snapshots++;
      },
    },
    reducedMotion: true,
  });
  assert.equal(calls, 3);
  assert.equal(snapshots, 0);
});
test('native view transitions await asynchronous DOM commits and preserve errors', async () => {
  let committed = false;
  const doc = {
    startViewTransition(update) {
      const done = Promise.resolve().then(update);
      return { ready: done, updateCallbackDone: done, finished: done, skipTransition() {} };
    },
  };
  await transitionView(
    async () => {
      await Promise.resolve();
      committed = true;
    },
    { document: doc },
  );
  assert.equal(committed, true);
  await assert.rejects(
    transitionView(
      () => {
        throw Error('commit failed');
      },
      { document: doc },
    ),
    /commit failed/,
  );
});

test('field click motion uses shared press/release lifecycle, excludes typing and disabled fields, and disposes held state', async () => {
  const { installControlMotion } = await import('../packages/core/dist/index.js');
  const saved = Object.fromEntries(
    ['Element', 'KeyboardEvent', 'PointerEvent', 'setTimeout', 'clearTimeout'].map((key) => [
      key,
      globalThis[key],
    ]),
  );
  const timers = new Map();
  let timerId = 0;
  let interaction = '0.166s',
    fast = '0.4s',
    reduced = false;
  class FakeElement {
    ownerDocument = {
      defaultView: {
        matchMedia: () => ({ matches: reduced }),
        getComputedStyle: () => ({
          getPropertyValue: (name) => (name === '--as-motion-interaction' ? interaction : fast),
        }),
      },
    };
    attributes = new Set();
    disabled = false;
    readOnly = true;
    select = false;
    overlay = false;
    closest(selector) {
      return selector.includes('.as-field-control') ? this : null;
    }
    matches(selector) {
      return selector
        .split(',')
        .some(
          (part) =>
            part.trim() === '.as-field-control' ||
            (part.trim() === '.as-field-control:not(select)' && !this.select) ||
            (part.trim() === 'select' && this.select) ||
            (part.trim() === 'select:not([data-popup=overlay])' && this.select && !this.overlay) ||
            (part.trim() === '.as-field-control[readonly]' && this.readOnly) ||
            (part.trim() === ':disabled' && this.disabled),
        );
    }
    setAttribute(name) {
      this.attributes.add(name);
    }
    removeAttribute(name) {
      this.attributes.delete(name);
    }
    contains(node) {
      return node === this;
    }
  }
  class KeyEvent extends Event {
    key = ' ';
    repeat = false;
  }
  class Pointer extends Event {
    relatedTarget = null;
  }
  const handlers = new Map();
  const root = {
    addEventListener(name, handler) {
      handlers.set(name, handler);
    },
    removeEventListener(name) {
      handlers.delete(name);
    },
  };
  const field = new FakeElement();
  const dispatch = (type, EventType = Pointer) => {
    const event = new EventType(type);
    Object.defineProperty(event, 'target', { value: field });
    handlers.get(type)(event);
  };
  let dispose;
  try {
    Object.assign(globalThis, {
      Element: FakeElement,
      KeyboardEvent: KeyEvent,
      PointerEvent: Pointer,
      setTimeout: (callback, delay) => {
        timers.set(++timerId, { callback, delay });
        return timerId;
      },
      clearTimeout: (id) => timers.delete(id),
    });
    dispose = installControlMotion(root);
    dispatch('keydown', KeyEvent);
    assert.equal(field.attributes.size, 0);
    field.readOnly = false;
    dispatch('keydown', KeyEvent);
    assert.equal(field.attributes.size, 0);
    field.disabled = true;
    dispatch('pointerdown');
    assert.equal(field.attributes.size, 0);
    field.disabled = false;
    dispatch('pointerdown');
    assert.ok(field.attributes.has('data-as-pressed'));
    dispatch('pointerup');
    const [holdId, hold] = [...timers][0];
    assert.ok(hold.delay <= 166);
    timers.delete(holdId);
    hold.callback();
    assert.ok(field.attributes.has('data-as-release'));
    assert.ok(!field.attributes.has('data-as-pressed'));
    assert.equal([...timers.values()][0].delay, 400);
    interaction = '275ms';
    fast = '0.72s';
    dispatch('pointerdown');
    dispatch('pointerup');
    const [customId, custom] = [...timers][0];
    assert.ok(
      custom.delay > 250 && custom.delay <= 275,
      'short-click flash follows the changed interaction token in milliseconds',
    );
    timers.delete(customId);
    custom.callback();
    assert.equal(
      [...timers.values()][0].delay,
      720,
      'release cleanup follows the changed fast token',
    );
    reduced = true;
    dispatch('pointerdown');
    dispatch('pointerup');
    const [reducedId, reducedTimer] = [...timers][0];
    assert.equal(reducedTimer.delay, 0);
    timers.delete(reducedId);
    reducedTimer.callback();
    assert.equal([...timers.values()][0].delay, 0);
    dispatch('pointerdown');
    assert.ok(field.attributes.has('data-as-pressed'));
    assert.ok(!field.attributes.has('data-as-release'));
    dispose();
    assert.equal(field.attributes.size, 0);
    assert.equal(timers.size, 0);
    assert.equal(handlers.size, 0);
  } finally {
    dispose?.();
    for (const [key, value] of Object.entries(saved)) {
      if (value === undefined) delete globalThis[key];
      else globalThis[key] = value;
    }
  }
});
