import test from 'node:test';
import assert from 'node:assert/strict';
import { formatChatTime } from '../packages/core/dist/index.js';
test('relative chat time follows elapsed boundaries and preserves 24h notation', () => {
  for (const [elapsed, label] of [
    [0, 'now'],
    [9000, 'now'],
    [10000, '10s'],
    [11000, '11s'],
    [59000, '59s'],
    [60000, '1m'],
    [3599000, '59m'],
    [3600000, '1h'],
    [86400000, '24h'],
    [172800000, '2d'],
  ])
    assert.equal(formatChatTime(0, elapsed), label);
  assert.equal(formatChatTime(1000, 0), 'now');
  assert.equal(formatChatTime(NaN, 0), '');
});
