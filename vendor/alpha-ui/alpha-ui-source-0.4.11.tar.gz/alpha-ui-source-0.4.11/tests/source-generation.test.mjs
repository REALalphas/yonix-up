import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { runInNewContext } from 'node:vm';
import test from 'node:test';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import ts from 'typescript';
import { formatComponentModule, formatDemoTemplate } from '../scripts/lib/template-format.mjs';

const run = promisify(execFile);

test('template formatting preserves adapter slots, interpolated paths and JSX whitespace', async () => {
  const source = [
    "const path = 'M 0,0 L 1,1';",
    'export default {',
    'props: `onPress@?: Handler<[]>;`,',
    'body: `const path = "${path}"; return <button onClick={p.onPress@}> before <span>{path}</span> after @CHILDREN@ </button>;`,',
    '};',
  ].join('\n');
  const formatted = await formatComponentModule(source, 'fixture.mjs');
  assert.equal(await formatComponentModule(formatted, 'fixture.mjs'), formatted);
  const evaluate = async (code) =>
    (await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'))).default;
  const before = await evaluate(source);
  const after = await evaluate(formatted);
  assert.match(after.props, /onPress@\?/);
  assert.match(after.body, /@CHILDREN@/);
  assert.match(after.body, /M 0,0 L 1,1/);
  const render = (body) => {
    const { outputText } = ts.transpileModule(
      'function Component(p) {' +
        body.replaceAll('@CHILDREN@', '{p.children}').replaceAll('@', '') +
        '}',
      { compilerOptions: { jsx: ts.JsxEmit.React, target: ts.ScriptTarget.ESNext } },
    );
    return renderToStaticMarkup(
      runInNewContext(outputText + '\nComponent(props);', {
        React: { createElement },
        props: { children: createElement('em', null, 'child') },
      }),
    );
  };
  assert.equal(render(after.body), render(before.body));
});

test('demo formatting preserves state and event slots without accumulating changes', async () => {
  const source = `@EXPORT@ { @STATE@ @UPDATE@ return <button @TAB_KEY_EVENT@ onClick@={()=>update({view:'base'})}>@COMPONENT_COUNT@ / @FRAMEWORK@</button>; } @EXPORT_END@`;
  const formatted = await formatDemoTemplate(source, 'Demo.tsx.template');
  const slots = (code) => code.match(/@[A-Z_]+@/g).sort();
  assert.deepEqual(slots(formatted), slots(source));
  assert.match(formatted, /onClick@/);
  assert.doesNotMatch(formatted, /__ALPHA_/);
  assert.equal(await formatDemoTemplate(formatted, 'Demo.tsx.template'), formatted);
});

test('generation rejects an orphaned component without deleting its source', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'alpha-orphan-check-'));
  const componentDir = join(directory, 'packages/react/src/components');
  const orphan = join(componentDir, 'Forgotten.tsx');
  const content = '// Unreviewed local work must not be silently deleted.\n';
  try {
    await mkdir(componentDir, { recursive: true });
    await writeFile(orphan, content);
    await assert.rejects(
      run(
        process.execPath,
        [new URL('../scripts/generate.mjs', import.meta.url).pathname, '--check'],
        {
          cwd: directory,
        },
      ),
      (error) => {
        assert.match(error.stderr, /Components absent from the canonical catalog:.*Forgotten\.tsx/);
        return true;
      },
    );
    assert.equal(await readFile(orphan, 'utf8'), content);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});
