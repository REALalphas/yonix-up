import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { AppShell, DrawerButton } from '../packages/react/dist/index.js';
test('shell width and two-line drawer content have explicit public variants', async () => {
  for (const width of ['content', 'container']) {
    const html = renderToStaticMarkup(
      createElement(AppShell, { serviceName: 'Test', items: [], selectedId: '', width }),
    );
    assert.match(html, new RegExp('data-width="' + width + '"'));
  }
  const normal = renderToStaticMarkup(
    createElement(AppShell, { serviceName: 'Test', items: [], selectedId: '' }),
  );
  assert.match(normal, /data-width="content"/);
  const html = renderToStaticMarkup(
    createElement(DrawerButton, {
      label: 'Обновление inputs',
      secondaryText: 'Успешно · 01.11.2026, 18:14:16',
      secondaryPlacement: 'below',
      selected: true,
    }),
  );
  assert.match(html, /data-secondary-placement="below"/);
  assert.match(html, /aria-current="page"/);
  assert.ok(html.includes('Обновление inputs'));
  for (const framework of ['react', 'qwik']) {
    assert.match(
      await readFile('packages/' + framework + '/src/components/AppShell.tsx', 'utf8'),
      /width\?: 'content' \| 'container'/,
    );
    assert.match(
      await readFile('packages/' + framework + '/src/components/DrawerButton.tsx', 'utf8'),
      /secondaryPlacement\?: 'inline' \| 'below'/,
    );
  }
});
