import { getCurrentWindow } from '@tauri-apps/api/window';
import type { DesktopBridge } from '@alpha/core';
export const tauriBridge: DesktopBridge = {
  minimize: () => getCurrentWindow().minimize(),
  toggleMaximize: () => getCurrentWindow().toggleMaximize(),
  close: () => getCurrentWindow().close(),
};
