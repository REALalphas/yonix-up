import { app, BrowserWindow, ipcMain } from 'electron';
import { fileURLToPath } from 'node:url';
const ui = process.env.ALPHA_UI_FRAMEWORK === 'qwik' ? 'qwik' : 'react';
function createWindow() {
  const window = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 320,
    minHeight: 600,
    backgroundColor: '#222222',
    webPreferences: {
      preload: fileURLToPath(new URL('./preload.cjs', import.meta.url)),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  window.loadFile(fileURLToPath(new URL(`../../../apps/${ui}/dist/index.html`, import.meta.url)));
}
for (const action of ['minimize', 'toggleMaximize', 'close'])
  ipcMain.handle(`alpha-window:${action}`, (event) => {
    const window = BrowserWindow.fromWebContents(event.sender);
    if (!window) return;
    if (action === 'minimize') window.minimize();
    if (action === 'close') window.close();
    if (action === 'toggleMaximize') window.isMaximized() ? window.unmaximize() : window.maximize();
  });
app.whenReady().then(createWindow);
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
