import { defineConfig } from 'vite';
import { qwikVite } from '@builder.io/qwik/optimizer';
export default defineConfig({
  base: './',
  plugins: [qwikVite({ srcDir: 'src', csr: true, entryStrategy: { type: 'smart' } })],
  define: {
    'import.meta.env.ALPHA_UI_VERSION': JSON.stringify(process.env.ALPHA_UI_VERSION || '0.1.0'),
  },
});
