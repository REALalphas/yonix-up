import { defineConfig } from 'vite';
export default defineConfig({
  base: './',
  esbuild: { jsx: 'automatic' },
  define: {
    'import.meta.env.ALPHA_UI_VERSION': JSON.stringify(process.env.ALPHA_UI_VERSION || '0.1.0'),
  },
});
