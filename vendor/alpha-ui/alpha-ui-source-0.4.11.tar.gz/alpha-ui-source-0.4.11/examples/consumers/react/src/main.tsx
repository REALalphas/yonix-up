import { installControlMotion } from '@alpha/core';
import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Stack, Text, Card, Button, Profile } from '@alpha/react';
import '@alpha/core/fonts.css';
import '@alpha/core/styles.css';
import './app.css';
function App() {
  const [count, setCount] = useState(0);
  return (
    <main className="alpha-ui" style={{ padding: 24 }}>
      <Stack gap={6}>
        <Text as="h1">Независимый React</Text>
        <Text font="mono">Alpha's UI {import.meta.env.ALPHA_UI_VERSION}</Text>
        <Text>
          В исходном проекте закреплена версия 0.1.0. Эта сборка использует выпуск центра.
        </Text>
        <Card>
          <Stack gap={4}>
            <Text as="h2">Аккаунт и состояния</Text>
            <Stack direction="row" gap={4}>
              <Profile />
              <Profile state="loading" />
              <Profile state="unstable" />
              <Profile state="error" />
            </Stack>
            <Button onPress={() => setCount(count + 1)}>Проверить действие</Button>
            <Text>Нажатий: {count}</Text>
          </Stack>
        </Card>
      </Stack>
    </main>
  );
}
createRoot(document.getElementById('root')!).render(<App />);

installControlMotion();
