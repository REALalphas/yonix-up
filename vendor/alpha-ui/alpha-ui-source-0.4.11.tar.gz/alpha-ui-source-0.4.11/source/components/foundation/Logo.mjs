export default {
  name: 'Logo',
  group: 'foundation',
  sources: ['66:463'],
  props: `
label?: string;
`,
  body: `
return (
  <img
    className={cx('as-logo', p.className)}
    src={assets.logo}
    width={40}
    height={40}
    alt={p.label ?? "Alpha's Service"}
  />
);
`,
};
