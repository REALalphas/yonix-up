export default {
  name: 'Badge',
  group: 'foundation',
  sources: ['4:86'],
  props: `
value: string | number;
`,
  body: `
return (
  <span className={cx('as-badge', p.className)} aria-label={String(p.value) + ' notifications'}>
    <span className="as-badge-label" data-overflow={String(p.value) === '99+' || undefined}>
      {p.value}
    </span>
  </span>
);
`,
};
