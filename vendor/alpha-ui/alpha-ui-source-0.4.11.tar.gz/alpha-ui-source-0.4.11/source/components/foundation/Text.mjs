export default {
  name: 'Text',
  group: 'foundation',
  sources: ['66:737', '797:1615'],
  props: `
as?: 'p' | 'span' | 'h1' | 'h2' | 'h3';
size?: 'sm' | 'md' | 'lg' | 'xl' | 'title' | 'heading';
tone?: 'default' | 'secondary' | 'muted';
font?: 'ui' | 'heading' | 'support' | 'mono';
weight?: 'regular' | 'medium' | 'bold';
`,
  body: `
const Tag = p.as ?? 'p';
const heading = Tag === 'h1' || Tag === 'h2' || Tag === 'h3';
return (
  <Tag
    className={cx('as-text', p.className)}
    data-size={p.size ?? (heading ? 'title' : 'md')}
    data-tone={p.tone ?? 'default'}
    data-font={p.font ?? (heading ? 'heading' : 'ui')}
    data-weight={p.weight ?? (heading ? 'bold' : 'regular')}
  >
    @CHILDREN@
  </Tag>
);
`,
};
