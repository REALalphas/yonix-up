import { readFileSync } from 'node:fs';
import { cornerArc } from './resize-geometry.mjs';
const tokens = JSON.parse(
  readFileSync(new URL('../../../packages/core/src/tokens.json', import.meta.url), 'utf8'),
);
const stroke = (15 * parseFloat(tokens.borderWidth.control)) / parseFloat(tokens.radius.control);
export const cornerIdle = cornerArc(15, stroke).path;
export const cornerActive = cornerArc(15, 2 * stroke).path;
export const cornerRoundIdle = cornerArc(15, stroke, 1).path;
export const cornerRoundActive = cornerArc(15, 2 * stroke, 1).path;
