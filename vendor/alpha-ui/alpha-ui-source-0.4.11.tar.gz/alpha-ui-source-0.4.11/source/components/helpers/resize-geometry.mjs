// Parallel to the inner edge of the field, rather than a scaled quarter circle.
export function cornerArc(radius, stroke, curvature = 1.2) {
  const exponent = 2 ** curvature;
  const inner = radius - stroke;
  const points = Array.from({ length: 65 }, (_, index) => {
    const angle = (index * Math.PI) / 128;
    const x = inner * Math.cos(angle) ** (2 / exponent);
    const y = inner * Math.sin(angle) ** (2 / exponent);
    const nx = (x / inner) ** (exponent - 1);
    const ny = (y / inner) ** (exponent - 1);
    const length = Math.hypot(nx, ny);
    return [radius + x - (1.5 * stroke * nx) / length, radius + y - (1.5 * stroke * ny) / length];
  });
  return {
    points,
    path: points
      .map(([x, y], index) => `${index ? 'L' : 'M'}${x.toFixed(5)} ${y.toFixed(5)}`)
      .join(' '),
  };
}
