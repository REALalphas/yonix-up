export default {
  name: 'ChatMessage',
  group: 'chat',
  sources: ['3:464'],
  props: `
author?: string;
text: string;
time?: string;
timestamp?: number;
outgoing?: boolean;
favorite?: boolean;
onFavorite@?: Handler<[]>;
onReply@?: Handler<[]>;
onEdit@?: Handler<[]>;
onDownload@?: Handler<[]>;
onForward@?: Handler<[]>;
`,
  body: `
@CHAT_TIME_LIFECYCLE@
const hasTimestamp = p.timestamp !== undefined && Number.isFinite(p.timestamp);
const timeLabel = hasTimestamp ? formatChatTime(p.timestamp!, @CHAT_NOW@) : p.time;
const hasActions = !!(
  p.onReply@ ||
  (p.outgoing
    ? p.onFavorite@ || p.onEdit@
    : p.onDownload@ || p.onForward@)
);
return (
  <div
    className={cx('as-chat-message-row', p.className)}
    data-outgoing={p.outgoing ? 'true' : undefined}
    data-timestamp={p.timestamp}
    data-author={p.author}
    tabIndex={hasActions ? 0 : undefined}
  >
    <article
      className="as-chat-message"
      data-outgoing={p.outgoing ? 'true' : undefined}
      aria-label={p.author}
    >
      <Text className="as-chat-message-text">{p.text}</Text>
      {timeLabel && (
        <time
          className="as-text as-chat-message-time"
          data-tone="secondary"
          dateTime={hasTimestamp ? new Date(p.timestamp!).toISOString() : undefined}
          title={hasTimestamp ? new Date(p.timestamp!).toLocaleString('ru-RU') : undefined}
        >
          {timeLabel}
        </time>
      )}
    </article>
    {hasActions && (
      <div className={'as-chat-message-actions'} aria-label="Действия сообщения">
        {p.outgoing && p.onFavorite@ && (
          <ChatButton
            icon="favorite"
            label={p.favorite ? 'Убрать из избранного' : 'В избранное'}
            pressed={p.favorite}
            onPress@={p.onFavorite@}
          />
        )}
        {p.outgoing && p.onEdit@ && (
          <ChatButton
            icon="edit"
            label="Редактировать"
            onPress@={p.onEdit@}
          />
        )}
        {p.onReply@ && (
          <ChatButton
            icon="messageReply"
            label="Ответить"
            onPress@={p.onReply@}
          />
        )}
        {!p.outgoing && p.onDownload@ && (
          <ChatButton
            icon="downloadFile"
            label="Скачать"
            onPress@={p.onDownload@}
          />
        )}
        {!p.outgoing && p.onForward@ && (
          <ChatButton
            icon="forward"
            label="Переслать"
            onPress@={p.onForward@}
          />
        )}
      </div>
    )}
  </div>
);
`,
};
