export default {
  name: 'ChatThread',
  group: 'chat',
  sources: ['3:464'],
  props: `
label?: string;
`,
  body: `
@CHAT_THREAD_LIFECYCLE@
return (
  <div
    ref={threadRoot}
    className={cx('as-chat-thread', p.className)}
    role="log"
    aria-label={p.label ?? 'Сообщения'}
    aria-live="polite"
    aria-relevant="additions"
  >
    @CHILDREN@
  </div>
);
`,
};
