export default {
  name: 'ChatSurface',
  group: 'chat',
  sources: ['3:464'],
  props: ``,
  body: `
@CHAT_SURFACE_LIFECYCLE@
return (
  <div ref={chatRoot} className={cx('as-chat-surface', p.className)}>
    @CHILDREN@
  </div>
);
`,
};
