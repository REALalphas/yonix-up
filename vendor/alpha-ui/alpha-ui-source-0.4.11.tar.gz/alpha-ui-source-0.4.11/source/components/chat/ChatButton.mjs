export default {
  name: 'ChatButton',
  group: 'chat',
  sources: ['3:464'],
  props: `
variant?: 'plain' | 'emoji' | 'attach' | 'record' | 'send';
icon?: IconName;
label?: string;
pressed?: boolean;
disabled?: boolean;
onPress@?: Handler<[]>;
`,
  body: `
const variant = p.variant ?? 'plain';
const defaults = {
  plain: { icon: 'messageReply', label: 'Ответить' },
  emoji: { icon: 'emoji', label: 'Добавить эмодзи' },
  attach: { icon: 'attachment', label: 'Прикрепить файл' },
  record: { icon: 'microphone', label: 'Записать голосовое сообщение' },
  send: { icon: 'send', label: 'Отправить' },
} as const;
return (
  <IconButton
    weight="bold"
    className={cx('as-chat-button as-chat-' + variant, p.className)}
    icon={p.icon ?? defaults[variant].icon}
    label={p.label ?? defaults[variant].label}
    pressed={p.pressed}
    disabled={p.disabled}
    onPress@={p.onPress@}
  />
);
`,
};
