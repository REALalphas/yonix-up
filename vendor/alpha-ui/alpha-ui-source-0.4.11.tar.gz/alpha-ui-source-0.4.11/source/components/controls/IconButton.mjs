export default {
  name: 'IconButton',
  group: 'controls',
  sources: ['794:1432'],
  status: 'extension',
  props: `
icon: IconName;
label: string;
weight?: 'regular' | 'bold';
pressed?: boolean;
disabled?: boolean;
onPress@?: Handler<[]>;
`,
  body: `
return (
  <button
    type="button"
    className={cx('as-button as-icon-button', p.className)}
    data-variant="simple"
    aria-label={p.label}
    aria-pressed={p.pressed}
    disabled={p.disabled}
    onClick={p.onPress@}
  >
    <Icon name={p.icon} weight={p.weight} />
  </button>
);
`,
};
