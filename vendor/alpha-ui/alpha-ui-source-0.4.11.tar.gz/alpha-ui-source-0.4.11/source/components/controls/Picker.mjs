export default {
  name: 'Picker',
  group: 'controls',
  sources: [],
  status: 'extension',
  props: `
label: string;
value: string;
options: { value: string; label: string; disabled?: boolean }[];
placeholder?: string;
disabled?: boolean;
variant?: 'plain' | 'service';
popup?: 'native' | 'overlay';
onValueChange@?: Handler<[value: string]>;
`,
  body: `
const generatedId = useId();
const pickerId = p.id ?? 'as-picker-' + generatedId;
const knownValue = p.options.some((option) => option.value === p.value);
return (
  <Select
    id={pickerId}
    className={cx('as-picker', p.className)}
    label={p.label}
    value={knownValue ? p.value : ''}
    options={p.options}
    placeholder={p.placeholder ?? 'Не выбрано'}
    disabled={p.disabled || !p.options.some((option) => !option.disabled)}
    variant={p.variant ?? 'plain'}
    popup={p.popup ?? (p.variant === 'service' ? 'native' : 'overlay')}
    onValueChange@={p.onValueChange@}
  />
);
`,
};
