import {
  cornerIdle,
  cornerActive,
  cornerRoundIdle,
  cornerRoundActive,
} from '../helpers/resize-paths.mjs';
export default {
  name: 'TextArea',
  group: 'controls',
  sources: [],
  status: 'extension',
  props: `
id: string;
label: string;
labelPlacement?: 'inside' | 'above';
icon?: IconName;
showIcon?: boolean;
value: string;
name?: string;
placeholder?: string;
disabled?: boolean;
readOnly?: boolean;
required?: boolean;
hint?: string;
error?: string;
onValueChange@?: Handler<[value: string]>;
rows?: number;
resize?: 'vertical' | 'both';
`,
  body: `
const fieldIcon = p.icon ?? 'type';
const hasMarker = p.showIcon ?? (!!p.readOnly || !!p.disabled);
const labelAbove =
  p.labelPlacement === 'above' || (p.labelPlacement !== 'inside' && !!(p.readOnly || p.disabled));
return (
  <div
    className={cx('as-field as-placeholder-field', p.className)}
    data-disabled={p.disabled ? 'true' : 'false'}
    data-error={p.error ? 'true' : 'false'}
    data-label-placement={labelAbove ? 'above' : 'inside'}
  >
    {labelAbove && (
      <label className="as-field-label" for@={p.id}>
        {p.label}
      </label>
    )}
    <span
      className="as-field-input-wrap"
      data-has-value={p.value.length ? 'true' : 'false'}
      data-has-marker={hasMarker ? 'true' : 'false'}
      data-multiline="true"
      tabIndex={p.disabled ? 0 : undefined}
      role={p.disabled ? 'button' : undefined}
      aria-label={p.disabled ? 'Редактирование недоступно: ' + p.label : undefined}
    >
      <textarea
        className="as-field-control as-textarea"
        id={p.id}
        name={p.name}
        value={p.value}
        disabled={p.disabled}
        required={p.required}
        aria-label={labelAbove ? undefined : p.label}
        aria-invalid={!!p.error || undefined}
        aria-describedby={p.error || p.hint ? p.id + '-description' : undefined}
        placeholder={labelAbove ? p.placeholder : undefined}
        readOnly={p.readOnly}
        rows={p.rows ?? 4}
        @TEXT_INPUT_HANDLER@
      />
      {!labelAbove && (
        <span className="as-field-placeholder" aria-hidden="true">
          <span className="as-field-placeholder-text">{p.placeholder ?? p.label}</span>
        </span>
      )}
      <span
        className="as-field-scrollbar"
        role="scrollbar"
        aria-orientation="vertical"
        aria-label={'Прокрутить: ' + p.label}
        aria-controls={p.id}
        tabIndex={0}
        hidden
      >
        <svg aria-hidden="true">
          <path className="as-field-scrollbar-hit" />
          <path className="as-field-scrollbar-thumb" />
        </svg>
      </span>
      <span
        className="as-field-resize"
        data-resize-axis={p.resize ?? 'vertical'}
        data-resize-handle={p.resize === 'both' ? 'corner' : 'bottom'}
        role={p.resize === 'both' ? 'button' : 'separator'}
        aria-orientation={p.resize === 'both' ? undefined : 'horizontal'}
        aria-label={(p.resize === 'both' ? 'Изменить размер: ' : 'Изменить высоту: ') + p.label}
        aria-controls={p.id}
        tabIndex={0}
      >
        {p.resize === 'both' && (
          <svg
            className="as-field-resize-arc"
            viewBox="0 0 30 30"
            style={{
              ['--as-corner-idle' as string]: 'path("${cornerIdle}")',
              ['--as-corner-active' as string]: 'path("${cornerActive}")',
              ['--as-corner-round-idle' as string]: 'path("${cornerRoundIdle}")',
              ['--as-corner-round-active' as string]: 'path("${cornerRoundActive}")',
            }}
            aria-hidden="true"
          >
            <path className="as-field-resize-hit" d="${cornerRoundIdle}" />
            <path d="${cornerRoundIdle}" />
          </svg>
        )}
      </span>
      {hasMarker &&
        (p.readOnly || p.disabled ? (
          <span className="as-field-readonly-marker" aria-hidden="true">
            <Icon name="pencilOff" weight="bold" />
          </span>
        ) : (
          <span className="as-field-type-marker" data-field-icon={fieldIcon} aria-hidden="true">
            <Icon name={fieldIcon} weight="bold" />
          </span>
        ))}
    </span>
    {(p.error || p.hint) && (
      <span id={p.id + '-description'} className="as-field-description">
        {p.error || p.hint}
      </span>
    )}
  </div>
);
`,
};
