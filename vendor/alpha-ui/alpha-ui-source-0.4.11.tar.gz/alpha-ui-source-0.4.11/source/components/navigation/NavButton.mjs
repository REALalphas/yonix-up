export default {
  name: 'NavButton',
  group: 'navigation',
  sources: ['4:86'],
  props: `
label: string;
icon?: IconName;
selected?: boolean;
notifications?: string | number;
onPress@?: Handler<[]>;
`,
  body: `
return (
  <button
    type="button"
    className={cx('as-nav-button', p.className)}
    data-selected={p.selected ? 'true' : 'false'}
    aria-current={p.selected ? 'page' : undefined}
    onClick={p.onPress@}
  >
    <span className="as-nav-icon">
      <Icon name={p.icon ?? 'key'} weight={p.selected ? 'bold' : 'regular'} />
      {p.notifications !== undefined && <Badge value={p.notifications} />}
    </span>
    <span className="as-nav-label">{p.label}</span>
  </button>
);
`,
};
