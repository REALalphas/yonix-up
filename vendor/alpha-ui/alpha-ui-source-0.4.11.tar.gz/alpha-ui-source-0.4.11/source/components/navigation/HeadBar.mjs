export default {
  name: 'HeadBar',
  group: 'navigation',
  sources: ['66:463', '66:760'],
  extensions: ['controlled service picker', 'optional borderless context picker'],
  props: `
serviceValue?: string;
serviceOptions?: { value: string; label: string; disabled?: boolean }[];
serviceLabel?: string;
serviceDisabled?: boolean;
context?: {
  label: string;
  value: string;
  options: { value: string; label: string; disabled?: boolean }[];
  placeholder?: string;
  disabled?: boolean;
};
onServiceChange@?: Handler<[value: string]>;
onContextChange@?: Handler<[value: string]>;
serviceName: string;
accountLabel?: string;
accountSrc?: string;
accountState?: 'default' | 'loading' | 'unstable' | 'error';
balance?: string;
onServicePress@?: Handler<[]>;
onAccountPress@?: Handler<[]>;
`,
  body: `
return (
  <header className={cx('as-headbar', p.className)}>
    <div className="as-headbar-service">
      {p.serviceOptions ? (
        <Picker
          label={p.serviceLabel ?? 'Сервис'}
          value={p.serviceValue ?? p.serviceName}
          options={p.serviceOptions}
          variant="service"
          disabled={p.serviceDisabled}
          onValueChange@={p.onServiceChange@}
        />
      ) : (
        <button
          type="button"
          className="as-service"
          disabled={p.serviceDisabled}
          onClick={p.onServicePress@}
          aria-label={'Switch service: ' + p.serviceName}
        >
          <Logo label="" />
          <span>{p.serviceName}</span>
          <Icon name="chevron" />
        </button>
      )}
    </div>
    {p.context && (
      <div className="as-headbar-context">
        <Picker
          label={p.context.label}
          value={p.context.value}
          options={p.context.options}
          placeholder={p.context.placeholder}
          disabled={p.context.disabled}
          onValueChange@={p.onContextChange@}
        />
      </div>
    )}
    <div className="as-headbar-actions">
      {p.balance && <span className="as-balance">{p.balance}</span>}
      <Profile
        label={p.accountLabel}
        src={p.accountSrc}
        state={p.accountState}
        onPress@={p.onAccountPress@}
      />
    </div>
  </header>
);
`,
};
