export default {
  name: 'DrawerDivider',
  group: 'navigation',
  sources: ['66:747'],
  props: `
label?: string;
`,
  body: `
return (
  <div className={cx('as-drawer-divider', p.className)}>
    <hr />
    {p.label && <span>{p.label}</span>}
  </div>
);
`,
};
