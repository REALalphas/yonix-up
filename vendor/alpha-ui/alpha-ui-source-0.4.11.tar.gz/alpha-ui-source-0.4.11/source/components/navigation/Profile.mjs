import { profileLoadingPath } from '../helpers/profile-loading-path.mjs';

export default {
  name: 'Profile',
  group: 'navigation',
  sources: ['30:383', '30:389', '30:402'],
  props: `
label?: string;
src?: string;
state?: 'default' | 'loading' | 'unstable' | 'error';
onPress@?: Handler<[]>;
`,
  body: `
const state = p.state ?? 'default';
const statusLabel =
  state === 'loading'
    ? 'Loading'
    : state === 'unstable'
      ? 'Connection unstable'
      : state === 'error'
        ? 'Account error'
        : '';
return (
  <button
    type="button"
    className={cx('as-profile', p.className)}
    data-state={state}
    aria-label={(p.label ?? 'Account') + (statusLabel ? ': ' + statusLabel : '')}
    aria-busy={state === 'loading' || undefined}
    onClick={p.onPress@}
  >
    {state === 'loading' && (
      <svg className="as-profile-loading-frame" viewBox="0 0 44 44" aria-hidden="true">
        <rect x="1" y="1" width="42" height="42" rx="14" pathLength="120" />
        <path d="${profileLoadingPath}" pathLength="120" />
      </svg>
    )}
    <span className="as-profile-backdrop as-profile-backdrop-near" aria-hidden="true">
      {state !== 'loading' && p.src && (
        <img className="as-profile-picture" src={p.src} alt="" draggable={false} />
      )}
    </span>
    <span className="as-profile-backdrop" aria-hidden="true">
      {state !== 'loading' && p.src && (
        <img className="as-profile-picture" src={p.src} alt="" draggable={false} />
      )}
    </span>
    <span className="as-profile-surface">
      {state !== 'loading' && p.src && (
        <img className="as-profile-picture" src={p.src} alt="" draggable={false} />
      )}
    </span>
    {(state === 'unstable' || state === 'error') && (
      <span className="as-profile-state" aria-hidden="true">
        <Icon name={state === 'unstable' ? 'error' : 'warning'} weight="bold" />
      </span>
    )}
  </button>
);
`,
};
