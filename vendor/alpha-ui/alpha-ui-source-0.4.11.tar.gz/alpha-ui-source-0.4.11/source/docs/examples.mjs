// These examples are compiled for both frameworks and displayed as their source on the site.
const options = `const options = [
  { value: 'react', label: 'React' },
  { value: 'qwik', label: 'Qwik' },
  { value: 'unavailable', label: 'Недоступный вариант', disabled: true },
];`;
const navigation = `const items: NavItem[] = [
  { id: 'overview', label: 'Обзор', icon: 'home' },
  { id: 'settings', label: 'Настройки', icon: 'settings' },
];`;

export const examples = {
  TextInput: {
    description: 'Управляемое поле с подписью, подсказкой и состоянием ошибки.',
    imports: ['TextInput', 'Text'],
    state: { value: '' },
    body: `<TextInput id="name" label="Название" value={state.value}
      hint="Введите название" onValueChange@={value => update({ value })} />
    <Text>Значение: {state.value || 'пусто'}</Text>
    <TextInput id="disabled-name" label="Недоступное поле" value="" disabled />`,
  },
  TextArea: {
    description: 'Многострочное управляемое поле с изменением размера.',
    imports: ['TextArea', 'Text'],
    state: { value: '' },
    body: `<TextArea id="description" label="Описание" value={state.value} rows={3}
      onValueChange@={value => update({ value })} />
    <Text>Символов: {state.value.length}</Text>
    <TextArea id="disabled-description" label="Недоступное поле" value="" disabled />`,
  },
  Checkbox: {
    description: 'Флажок с управляемым выбором и доступной подписью.',
    imports: ['Checkbox', 'Text'],
    state: { checked: false },
    body: `<Checkbox id="choice" label="Сохранить выбор для следующих сеансов и других открытых окон"
      checked={state.checked} onCheckedChange@={checked => update({ checked })} />
    <Text>{state.checked ? 'Выбрано' : 'Не выбрано'}</Text>
    <Checkbox id="disabled-choice" label="Недоступный вариант" checked={false} disabled />`,
  },
  Switch: {
    description: 'Переключатель с управляемым состоянием.',
    imports: ['Switch', 'Text'],
    state: { checked: false },
    body: `<Switch id="notifications" label="Уведомления" checked={state.checked}
      onCheckedChange@={checked => update({ checked })} />
    <Text>{state.checked ? 'Включены' : 'Выключены'}</Text>
    <Switch id="disabled-notifications" label="Недоступный переключатель" checked={false} disabled />`,
  },
  Select: {
    description: 'Выбор из списка: системный popup или общий оверлей библиотеки.',
    imports: ['Select', 'Text'],
    state: { value: 'react' },
    setup: options,
    body: `<Select id="framework" label="Фреймворк" value={state.value} options={options}
      popup="overlay" onValueChange@={value => update({ value })} />
    <Select id="native-framework" label="Системный список" value={state.value} options={options}
      popup="native" onValueChange@={value => update({ value })} />
    <Text>Выбрано: {state.value}</Text>`,
  },
  Picker: {
    description: 'Компактный управляемый выбор без постоянной рамки.',
    imports: ['Picker', 'Text'],
    state: { value: 'react' },
    setup: options,
    body: `<Picker label="Фреймворк" value={state.value} options={options} popup="overlay"
      onValueChange@={value => update({ value })} />
    <Text>Выбрано: {state.value}</Text>`,
  },
  Icon: {
    description: 'Иконки Lucide с начертаниями regular и bold.',
    imports: ['Icon', 'Text'],
    body: `<Stack direction="row" gap={4}>
      <Icon name="settings" label="Настройки" />
      <Icon name="settings" label="Настройки, bold" weight="bold" />
      <Icon name="search" label="Поиск" />
    </Stack>
    <Text>Regular — 1.5, bold — 2; размер — 24 × 24 при базе 16.</Text>`,
  },
  Logo: {
    description: 'Логотип сервиса как отдельный SVG-ресурс.',
    imports: ['Logo'],
    body: '<Logo label="Alpha\'s UI" />',
  },
  Text: {
    description: 'Типографика: Noto Sans, Manrope и Fira Code.',
    imports: ['Text'],
    body: `<Text as="h2" size="title">Manrope · Заголовок</Text>
    <Text>Noto Sans · Основной текст интерфейса</Text>
    <Text tone="secondary">Дополнительное пояснение</Text>
    <Text font="mono">Fira Code · 384 kHz</Text>`,
  },
  Stack: {
    description: 'Компоновка элементов с интервалами из общих токенов.',
    imports: ['Switch', 'Card', 'Text'],
    state: { horizontal: false },
    body: `<Switch id="direction" label="Горизонтальное направление" checked={state.horizontal}
      onCheckedChange@={horizontal => update({ horizontal })} />
    <Stack direction={state.horizontal ? 'row' : 'column'} gap={4}>
      <Card><Text>Первый блок</Text></Card>
      <Card><Text>Второй блок</Text></Card>
      <Card><Text>Третий блок</Text></Card>
    </Stack>`,
  },
  Card: {
    description: 'Поверхность для композиции содержимого.',
    imports: ['Card', 'Text', 'Button'],
    state: { clicks: 0 },
    body: `<Card><Stack gap={4}>
      <Text as="h2">Карточка</Text>
      <Text>Нажатий: {state.clicks}</Text>
      <Button onPress@={() => update({ clicks: state.clicks + 1 })}>Действие</Button>
    </Stack></Card>`,
  },
  ChatSurface: {
    description: 'Общая поверхность для компонентов чата.',
    imports: ['ChatSurface', 'ChatThread', 'ChatMessage'],
    body: `<ChatSurface><ChatThread>
      <ChatMessage text="Входящее сообщение" />
      <ChatMessage text="Исходящее сообщение" outgoing />
    </ChatThread></ChatSurface>`,
  },
  ChatMessage: {
    description: 'Сообщение с действиями, доступными при наведении и фокусе.',
    imports: ['ChatSurface', 'ChatThread', 'ChatMessage', 'Text'],
    state: { favorite: false, notice: '' },
    body: `<ChatSurface><ChatThread>
      <ChatMessage text="Наведите курсор или перейдите к действиям клавишей Tab"
        favorite={state.favorite}
        onFavorite@={() => update({ favorite: !state.favorite })}
        onReply@={() => update({ notice: 'Выбрано действие «Ответить»' })} />
    </ChatThread></ChatSurface>
    <Text>{state.favorite ? 'В избранном' : 'Не в избранном'}</Text>
    <Text>{state.notice}</Text>`,
  },
  ChatButton: {
    description: 'Действия композера: emoji, attach, record и send.',
    imports: ['ChatSurface', 'ChatButton', 'Text'],
    state: { notice: '' },
    body: `<ChatSurface><Stack direction="row" gap={3}>
      <ChatButton variant="emoji" onPress@={() => update({ notice: 'Emoji' })} />
      <ChatButton variant="attach" onPress@={() => update({ notice: 'Вложение' })} />
      <ChatButton variant="record" onPress@={() => update({ notice: 'Запись' })} />
      <ChatButton variant="send" onPress@={() => update({ notice: 'Отправка' })} />
    </Stack></ChatSurface>
    <Text>{state.notice || 'Выберите действие'}</Text>`,
  },
  ChatInput: {
    description: 'Управляемое поле сообщения.',
    imports: ['ChatSurface', 'ChatInput', 'Text'],
    state: { value: '' },
    body: `<ChatSurface><ChatInput value={state.value} onValueChange@={value => update({ value })} /></ChatSurface>
    <Text>Символов: {state.value.length}</Text>`,
  },
  ChatThread: {
    description: 'Лента сообщений с общей группировкой.',
    imports: ['ChatSurface', 'ChatThread', 'ChatMessage'],
    body: `<ChatSurface><ChatThread label="Пример переписки">
      <ChatMessage text="Первое сообщение" />
      <ChatMessage text="Следующее сообщение" />
      <ChatMessage text="Ответ" outgoing />
    </ChatThread></ChatSurface>`,
  },
  ChatComposer: {
    description: 'Композиция поля сообщения и действий отправки.',
    imports: ['ChatSurface', 'ChatComposer', 'Text'],
    state: { value: '', sent: '', recording: false },
    body: `<ChatSurface><ChatComposer value={state.value}
      onValueChange@={value => update({ value })}
      onEmoji@={() => update({ value: state.value + '🙂' })}
      onRecord@={() => update({ recording: !state.recording })}
      onSend@={() => { if (state.value.trim()) update({ sent: state.value, value: '' }); }} />
    </ChatSurface>
    <Text>{state.sent ? 'Отправлено локально: ' + state.sent : 'Введите сообщение'}</Text>
    <Text>{state.recording ? 'Выбрана запись голосового сообщения' : 'Запись не выбрана'}</Text>`,
    notes:
      'Отправка и выбор записи в примере меняют только состояние браузера. Доступ к микрофону и сохранение сообщений подключает приложение.',
  },
  Badge: {
    description: 'Счётчик уведомлений в составе навигационного элемента.',
    imports: ['NavButton', 'Button', 'Text'],
    state: { count: 3, selected: false },
    body: `<Stack direction="row" align="start" gap={4}>
      <NavButton label="Чат" icon="messageReply"
        notifications={state.count > 99 ? '99+' : state.count} selected={state.selected}
        onPress@={() => update({ selected: !state.selected })} />
    </Stack>
    <Stack direction="row" gap={3}>
      <Button onPress@={() => update({ count: state.count + 1 })}>Добавить уведомление</Button>
      <Button variant="simple" onPress@={() => update({ count: 100 })}>Показать 99+</Button>
    </Stack>
    <Text>Уведомлений: {state.count}</Text>`,
    notes:
      'Badge — часть навигационного элемента, а не самостоятельный блок. Передавайте значение через notifications у NavButton или элементов BottomNav. Пример использует штатный NavButton, который сам размещает Badge рядом с иконкой.',
  },
  Button: {
    description: 'Кнопка с общими состояниями нажатия, загрузки и недоступности.',
    imports: ['Button', 'Text'],
    state: { clicks: 0 },
    body: `<Button onPress@={() => update({ clicks: state.clicks + 1 })}>
      Нажать кнопку с длинной подписью
    </Button>
    <Text>Нажатий: {state.clicks}</Text>
    <Stack direction="row" gap={3}>
      <Button variant="simple" onPress@={() => update({ clicks: state.clicks + 1 })}>Simple</Button>
      <Button variant="blank" onPress@={() => update({ clicks: state.clicks + 1 })}>Blank</Button>
      <Button loading>Загрузка</Button>
      <Button disabled>Недоступно</Button>
    </Stack>`,
  },
  IconButton: {
    description: 'Действие с иконкой и обязательным доступным названием.',
    imports: ['IconButton', 'Text'],
    state: { pressed: false },
    body: `<IconButton icon="heart" label="Избранное" pressed={state.pressed}
      onPress@={() => update({ pressed: !state.pressed })} />
    <Text>{state.pressed ? 'Выбрано' : 'Не выбрано'}</Text>
    <IconButton icon="settings" label="Недоступные настройки" disabled />`,
  },
  Profile: {
    description: 'Профиль в состояниях default, loading, unstable и error.',
    imports: ['Profile', 'Text'],
    state: { notice: '' },
    body: `<Stack direction="row" gap={3}>
      <Stack align="start" gap={2}><Text>Обычный</Text>
        <Profile label="Аккаунт" onPress@={() => update({ notice: 'Открыть аккаунт' })} />
      </Stack>
      <Stack align="start" gap={2}><Text>Загрузка</Text>
        <Profile label="Загрузка аккаунта" state="loading" />
      </Stack>
      <Stack align="start" gap={2}><Text>Нестабильно</Text>
        <Profile label="Нестабильное соединение" state="unstable"
          onPress@={() => update({ notice: 'Нестабильное соединение' })} />
      </Stack>
      <Stack align="start" gap={2}><Text>Ошибка</Text>
        <Profile label="Ошибка аккаунта" state="error"
          onPress@={() => update({ notice: 'Ошибка аккаунта' })} />
      </Stack>
    </Stack>
    <Text>{state.notice || 'Изображение профиля передаёт приложение через src.'}</Text>`,
  },
  HeadBar: {
    description: 'Шапка с управляемым выбором сервиса и необязательным контекстом.',
    imports: ['HeadBar', 'Text'],
    state: { value: 'react', context: 'react', notice: '' },
    setup: options,
    body: `<HeadBar serviceName="Alpha's UI" serviceValue={state.value} serviceOptions={options}
      onServiceChange@={value => update({ value })}
      context={{ label: 'Контекст', value: state.context, options }}
      onContextChange@={context => update({ context })}
      onAccountPress@={() => update({ notice: 'Открыть аккаунт' })} />
    <Text>Сервис: {state.value} · Контекст: {state.context}</Text>
    <Text>{state.notice}</Text>`,
  },
  NavButton: {
    description: 'Кнопка навигации с выбором и счётчиком уведомлений.',
    imports: ['NavButton', 'Text'],
    state: { selected: false },
    body: `<NavButton label="Чат" icon="messageReply" notifications="3" selected={state.selected}
      onPress@={() => update({ selected: !state.selected })} />
    <Text>{state.selected ? 'Выбрано' : 'Не выбрано'}</Text>`,
  },
  BottomNav: {
    description: 'Нижняя навигация с управляемым активным пунктом.',
    imports: ['BottomNav', 'Text', 'type NavItem'],
    state: { selectedId: 'overview' },
    setup: navigation,
    body: `<BottomNav items={items} selectedId={state.selectedId}
      onSelect@={selectedId => update({ selectedId })} />
    <Text>Выбрано: {state.selectedId}</Text>`,
  },
  DrawerButton: {
    description: 'Пункт бокового меню с дополнительным пояснением.',
    imports: ['DrawerButton'],
    state: { selected: false },
    body: `<DrawerButton label="Настройки" icon="settings" secondaryText="Дополнительное пояснение под названием"
      secondaryPlacement="below" selected={state.selected}
      onPress@={() => update({ selected: !state.selected })} />`,
  },
  DrawerDivider: {
    description: 'Разделитель группы боковой навигации.',
    imports: ['DrawerDivider', 'DrawerButton'],
    state: { selectedId: 'overview' },
    body: `<DrawerButton label="Обзор" icon="home" selected={state.selectedId === 'overview'}
      onPress@={() => update({ selectedId: 'overview' })} />
    <DrawerDivider label="Аккаунт" />
    <DrawerButton label="Настройки" icon="settings" selected={state.selectedId === 'settings'}
      onPress@={() => update({ selectedId: 'settings' })} />`,
  },
  Sidebar: {
    description: 'Боковая навигация с управляемым активным пунктом.',
    imports: ['Sidebar', 'Text', 'type NavItem'],
    state: { selectedId: 'overview' },
    setup: navigation,
    body: `<Sidebar items={items} selectedId={state.selectedId}
      onSelect@={selectedId => update({ selectedId })} />
    <Text>Выбрано: {state.selectedId}</Text>`,
  },
  AppShell: {
    description: 'Адаптивная оболочка: шапка, навигация и содержимое приложения.',
    imports: ['AppShell', 'Text', 'type NavItem'],
    state: { selectedId: 'overview' },
    setup: navigation,
    shell: true,
    body: `<AppShell serviceName="Alpha's UI" items={items} selectedId={state.selectedId} width="container"
      onSelect@={selectedId => update({ selectedId })}>
      <Stack gap={4}><Text as="h2">{items.find(item => item.id === state.selectedId)?.label}</Text>
      <Text>Содержимое выбранного раздела.</Text></Stack>
    </AppShell>`,
  },
};
