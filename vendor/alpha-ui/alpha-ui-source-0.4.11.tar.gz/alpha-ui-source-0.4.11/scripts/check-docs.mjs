import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { packageNames } from './lib/package-files.mjs';
import { checkDocumentLinks } from './lib/document-links.mjs';

const root = resolve(import.meta.dirname, '..');
const excluded = new Set([
  '.git',
  'node_modules',
  'dist',
  'dist-examples',
  'releases',
  'output',
  'local-assets',
  '.alpha-builds',
  '.vite',
  '.astro',
  'coverage',
  'test-results',
  'playwright-report',
  'secrets',
]);
async function collect(directory = '') {
  const files = [];
  for (const entry of await readdir(resolve(root, directory), { withFileTypes: true })) {
    if (excluded.has(entry.name) || entry.name.includes('.sync-conflict-')) continue;
    const file = directory ? `${directory}/${entry.name}` : entry.name;
    if (file === 'apps/docs/src/content/docs' || file === 'apps/docs/public') continue;
    if (entry.isDirectory()) files.push(...(await collect(file)));
    else if (entry.isFile()) files.push(file);
  }
  return files;
}
const manifests = {};
for (const name of packageNames) {
  const pkg = JSON.parse(await readFile(resolve(root, `packages/${name}/package.json`), 'utf8'));
  manifests[pkg.name] = pkg;
}
const result = await checkDocumentLinks({ root, files: await collect(), manifests });
assert.equal(result.issues.length, 0, result.issues.join('\n'));
console.log(
  `${result.documents} documents: ${result.localLinks} local links and ${result.packageReferences} package references OK.`,
);
