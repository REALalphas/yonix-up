import assert from 'node:assert/strict';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve, posix } from 'node:path';
import { docsBase } from './lib/docs-site.mjs';
import { collectSourceFiles, extractReleaseSource } from './lib/release-source.mjs';

const root = resolve(import.meta.dirname, '../apps/docs/dist');
const base = docsBase(process.env.DOCS_BASE_PATH);
const origin = process.env.DOCS_SITE_URL || 'https://docs.invalid';
async function collect(directory = '') {
  const files = [];
  for (const entry of await readdir(resolve(root, directory), { withFileTypes: true })) {
    const file = posix.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...(await collect(file)));
    else files.push(file);
  }
  return files;
}
const files = new Set(await collect());
const html = new Map();
for (const file of files)
  if (file.endsWith('.html')) html.set(file, await readFile(resolve(root, file), 'utf8'));
const issues = [];
const localUrls = new Set();
let checked = 0;
for (const [file, content] of html) {
  const current = new URL(base + file.replace(/index\.html$/, ''), origin);
  // A 404 page has a canonical URL for search engines, not a navigable route.
  const linkedContent = content.replace(/<link\b[^>]*\brel=["']canonical["'][^>]*>/gi, '');
  for (const match of linkedContent.matchAll(/\b(?:href|src)=["']([^"']*)["']/g)) {
    const target = match[1].replaceAll('&amp;', '&');
    const url = new URL(target, current);
    if (url.origin !== current.origin || url.protocol !== current.protocol) continue;
    checked++;
    if (!url.pathname.startsWith(base)) {
      issues.push(`${file}: link escapes configured base: ${target}`);
      continue;
    }
    const path = decodeURIComponent(url.pathname.slice(base.length));
    if (
      /^examples\/(?:react|qwik)\/index\.html$/.test(path) &&
      !url.searchParams.has('component')
    ) {
      issues.push(`${file}: documentation links must select an isolated component: ${target}`);
    }
    if (/^examples\/(?:react|qwik)\/$/.test(path)) {
      issues.push(`${file}: use an explicit index.html for examples in Astro dev: ${target}`);
    }
    url.hash = '';
    localUrls.add(url.pathname + url.search);
    const destination = files.has(path) ? path : posix.join(path, 'index.html');
    if (!files.has(destination)) issues.push(`${file}: missing ${target}`);
    else if (url.hash && html.has(destination)) {
      const fragment = decodeURIComponent(url.hash.slice(1));
      const ids = [...html.get(destination).matchAll(/\bid=["']([^"']*)["']/g)].map(
        (match) => match[1],
      );
      if (!ids.includes(fragment)) issues.push(`${file}: missing anchor ${target}`);
    }
  }
}
assert.equal(issues.length, 0, issues.join('\n'));
console.log(`${html.size} HTML pages: ${checked} local links and assets OK (base ${base}).`);

for (const file of files) {
  if (!/^examples\/(?:react|qwik)\/.*\.(?:js|css)$/.test(file)) continue;
  assert.doesNotMatch(
    await readFile(resolve(root, file), 'utf8'),
    /demo-toolbar|demo-catalog|alpha-ui\.demo\.tabs/,
    `The full demo site must not be bundled with documentation examples: ${file}`,
  );
}

const server = process.argv.find((argument) => argument.startsWith('--url='))?.slice(6);
if (server) {
  // Read each server's actual HTML: dev source modules and production bundles have different URLs.
  const pending = new Set([...localUrls].filter((path) => !path.startsWith(base + '_astro/')));
  const queue = [...pending];
  await Promise.all(
    Array.from({ length: 6 }, async () => {
      while (queue.length) {
        const path = queue.shift();
        const response = await fetch(new URL(path, server));
        // Dev renders its 404 route with status 404; static hosts may serve the HTML file with 200.
        const expected = path === base + '404.html' && response.status === 404 ? 404 : 200;
        assert.equal(response.status, expected, `HTTP ${response.status}: ${path}`);
        if (response.headers.get('content-type')?.includes('text/html')) {
          const body = await response.text();
          for (const match of body.matchAll(/\b(?:href|src)=["']([^"']*)["']/g)) {
            const url = new URL(match[1].replaceAll('&amp;', '&'), response.url);
            if (url.origin !== new URL(server).origin) continue;
            const target = url.pathname + url.search;
            if (!pending.has(target)) {
              pending.add(target);
              queue.push(target);
            }
          }
        } else await response.arrayBuffer();
      }
    }),
  );
  console.log(`${pending.size} actual HTTP routes and resources OK (${server}).`);
}

const workspace = resolve(import.meta.dirname, '..');
const downloads = resolve(root, 'downloads');
const manifest = JSON.parse(await readFile(resolve(downloads, 'source.json'), 'utf8'));
assert.equal(manifest.schema, 1, 'Documentation source manifest schema');
const catalog = JSON.parse(
  await readFile(resolve(workspace, 'packages/core/src/catalog.json'), 'utf8'),
);
assert.equal(manifest.version, catalog.version, 'Documentation source version');
const scratch = await mkdtemp(resolve(tmpdir(), 'alpha-docs-source-'));
try {
  const sources = await extractReleaseSource({ release: downloads, manifest, target: scratch });
  assert.deepEqual(sources, await collectSourceFiles(workspace), 'Documentation source file set');
  for (const file of sources) {
    assert.deepEqual(
      await readFile(resolve(scratch, file)),
      await readFile(resolve(workspace, file)),
      `Documentation source differs from workspace: ${file}`,
    );
  }
  console.log(`Documentation source: ${sources.length} files, SHA-512 and exact contents OK.`);
} finally {
  await rm(scratch, { recursive: true, force: true });
}
