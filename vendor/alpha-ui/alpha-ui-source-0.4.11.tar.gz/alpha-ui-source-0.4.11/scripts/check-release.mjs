import assert from 'node:assert/strict';
import { mkdtemp, cp, mkdir, readFile, readdir, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve, sep, basename } from 'node:path';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { extract } from 'tar';
import { runNpm } from './lib/npm.mjs';
import { packageNames } from './lib/package-files.mjs';
import { stagePackage } from './lib/package-staging.mjs';
import { extractReleaseSource } from './lib/release-source.mjs';
if (!process.argv[2])
  throw new Error('Usage: node scripts/check-release.mjs /path/to/releases/X.Y.Z');
const release = resolve(process.argv[2]);
const manifest = JSON.parse(await readFile(join(release, 'manifest.json')));
const root = await mkdtemp(join(tmpdir(), 'alpha-consumer-'));

async function fileContents(directory, prefix = '') {
  const files = {};
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const file = prefix + entry.name;
    if (entry.isDirectory())
      Object.assign(files, await fileContents(join(directory, entry.name), file + '/'));
    else {
      assert.ok(entry.isFile(), `Unexpected package entry: ${file}`);
      files[file] = createHash('sha512')
        .update(await readFile(join(directory, entry.name)))
        .digest('hex');
    }
  }
  return files;
}

try {
  if (manifest.source) {
    const source = join(root, 'source');
    await extractReleaseSource({ release, manifest, target: source });
    await runNpm(['ci'], { cwd: source, onOutput: (t) => process.stdout.write(t) });
    await runNpm(['run', 'verify'], { cwd: source, onOutput: (t) => process.stdout.write(t) });
    for (const name of packageNames) {
      const item = manifest.packages[`@alpha/${name}`];
      assert.match(item.file, /^[a-zA-Z0-9._-]+\.tgz$/);
      const bytes = await readFile(join(release, item.file));
      assert.equal(bytes.length, item.size, `${name}: archive size`);
      assert.equal(
        `sha512-${createHash('sha512').update(bytes).digest('base64')}`,
        item.integrity,
        `${name}: archive integrity`,
      );
      const rebuilt = join(root, `rebuilt-${name}`);
      await stagePackage({ root: source, target: rebuilt, name, version: manifest.version });
      const distributed = join(root, `distributed-${name}`);
      await mkdir(distributed);
      await extract({ file: join(release, item.file), cwd: distributed, strip: 1, strict: true });
      assert.deepEqual(
        await fileContents(rebuilt),
        await fileContents(distributed),
        `${name}: packages must match their corresponding source build`,
      );
    }
    console.log('Corresponding source: clean install, verify and all four rebuilt packages — OK');
  } else {
    console.log('Legacy release without manifest.source: corresponding source was not checked.');
  }
  for (const framework of ['react', 'qwik']) {
    const project = join(root, framework);
    await cp(resolve('examples/consumers', framework), project, {
      recursive: true,
      filter: (p) => !['.alpha-builds', 'node_modules'].includes(basename(p)),
    });
    await new Promise((resolve, reject) => {
      const child = spawn(
        process.execPath,
        [join(release, 'install.mjs'), '--project', project, '--framework', framework],
        { shell: false, windowsHide: true, stdio: 'inherit' },
      );
      child.once('error', reject);
      child.once('exit', (code) =>
        code === 0 ? resolve() : reject(Error('Установщик не выполнился')),
      );
    });
    for (const name of ['core', framework, 'project-server'])
      assert.equal(
        JSON.parse(await readFile(join(project, `node_modules/@alpha/${name}/package.json`)))
          .version,
        manifest.version,
      );
    assert.match(await readFile(join(project, 'AGENTS.md'), 'utf8'), /ALPHA_UI_AGENT_RULES/);
    assert.match(await readFile(join(project, 'ALPHA_UI_AGENT_RULES.md'), 'utf8'), /ui-unspec/);
    const suffix = framework === 'react' ? 'index.js' : 'index.qwik.mjs';
    const exports = await import(
      pathToFileURL(join(project, `node_modules/@alpha/${framework}/dist/${suffix}`)).href
    );
    assert.equal(typeof exports.Profile, 'function');
    const provider = await import(
      pathToFileURL(join(project, 'node_modules/@alpha/project-server/src/server.mjs')).href
    );
    assert.equal(typeof provider.createProjectServer, 'function');
    await stat(
      join(
        project,
        'node_modules/.bin',
        process.platform === 'win32' ? 'alpha-project.cmd' : 'alpha-project',
      ),
    );
    await runNpm(['run', 'build'], {
      cwd: project,
      env: { ...process.env, ALPHA_UI_VERSION: manifest.version },
    });
    await stat(join(project, 'dist/index.html'));
    console.log(
      `${framework}: пакет ${manifest.version}, правила агента, сервер проекта и независимая сборка — OK`,
    );
  }
} finally {
  const target = resolve(root);
  assert.ok(
    target.startsWith(resolve(tmpdir()) + sep) && basename(target).startsWith('alpha-consumer-'),
  );
  await rm(target, { recursive: true, force: true });
}
