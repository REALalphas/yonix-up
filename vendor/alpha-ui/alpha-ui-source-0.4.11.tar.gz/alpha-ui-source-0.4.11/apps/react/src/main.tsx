import { createRoot } from 'react-dom/client';
import { Demo } from './demo';
import { examples } from './examples';
import '@alpha/core/fonts.css';
import '@alpha/core/styles.css';
import '../../shared/demo.css';
import '../../shared/examples.css';
import { installControlMotion } from '@alpha/core';
installControlMotion();
const componentName = new URLSearchParams(window.location.search).get('component');
const Example =
  componentName && Object.hasOwn(examples, componentName)
    ? examples[componentName as keyof typeof examples]
    : undefined;
if (Example) document.body.dataset.example = componentName!;
createRoot(document.getElementById('root')!).render(Example ? <Example /> : <Demo />);
