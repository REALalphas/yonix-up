// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { Stack, Logo } from '@alpha/react';
export function LogoExample() {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Logo label="Alpha's UI" />
      </Stack>
    </div>
  );
}
