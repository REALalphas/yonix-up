// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { Stack, Text } from '@alpha/react';
export function TextExample() {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Text as="h2" size="title">
          Manrope · Заголовок
        </Text>
        <Text>Noto Sans · Основной текст интерфейса</Text>
        <Text tone="secondary">Дополнительное пояснение</Text>
        <Text font="mono">Fira Code · 384 kHz</Text>
      </Stack>
    </div>
  );
}
