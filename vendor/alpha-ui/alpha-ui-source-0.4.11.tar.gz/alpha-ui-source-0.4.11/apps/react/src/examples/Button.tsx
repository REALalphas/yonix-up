// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, Button, Text } from '@alpha/react';
export function ButtonExample() {
  const [state, setState] = useState({ clicks: 0 });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Button onPress={() => update({ clicks: state.clicks + 1 })}>
          Нажать кнопку с длинной подписью
        </Button>
        <Text>Нажатий: {state.clicks}</Text>
        <Stack direction="row" gap={3}>
          <Button variant="simple" onPress={() => update({ clicks: state.clicks + 1 })}>
            Simple
          </Button>
          <Button variant="blank" onPress={() => update({ clicks: state.clicks + 1 })}>
            Blank
          </Button>
          <Button loading>Загрузка</Button>
          <Button disabled>Недоступно</Button>
        </Stack>
      </Stack>
    </div>
  );
}
