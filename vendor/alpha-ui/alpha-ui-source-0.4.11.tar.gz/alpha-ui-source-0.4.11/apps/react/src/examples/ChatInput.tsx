// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, ChatSurface, ChatInput, Text } from '@alpha/react';
export function ChatInputExample() {
  const [state, setState] = useState({ value: '' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatInput value={state.value} onValueChange={(value) => update({ value })} />
        </ChatSurface>
        <Text>Символов: {state.value.length}</Text>
      </Stack>
    </div>
  );
}
