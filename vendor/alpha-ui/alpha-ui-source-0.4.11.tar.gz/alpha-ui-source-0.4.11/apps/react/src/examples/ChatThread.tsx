// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { Stack, ChatSurface, ChatThread, ChatMessage } from '@alpha/react';
export function ChatThreadExample() {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatThread label="Пример переписки">
            <ChatMessage text="Первое сообщение" />
            <ChatMessage text="Следующее сообщение" />
            <ChatMessage text="Ответ" outgoing />
          </ChatThread>
        </ChatSurface>
      </Stack>
    </div>
  );
}
