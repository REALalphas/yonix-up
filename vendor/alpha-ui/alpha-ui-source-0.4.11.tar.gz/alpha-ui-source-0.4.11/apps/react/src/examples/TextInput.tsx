// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, TextInput, Text } from '@alpha/react';
export function TextInputExample() {
  const [state, setState] = useState({ value: '' });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <TextInput
          id="name"
          label="Название"
          value={state.value}
          hint="Введите название"
          onValueChange={(value) => update({ value })}
        />
        <Text>Значение: {state.value || 'пусто'}</Text>
        <TextInput id="disabled-name" label="Недоступное поле" value="" disabled />
      </Stack>
    </div>
  );
}
