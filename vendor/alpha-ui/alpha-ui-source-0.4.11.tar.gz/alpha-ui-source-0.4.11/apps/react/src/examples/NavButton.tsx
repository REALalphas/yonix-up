// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, NavButton, Text } from '@alpha/react';
export function NavButtonExample() {
  const [state, setState] = useState({ selected: false });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <NavButton
          label="Чат"
          icon="messageReply"
          notifications="3"
          selected={state.selected}
          onPress={() => update({ selected: !state.selected })}
        />
        <Text>{state.selected ? 'Выбрано' : 'Не выбрано'}</Text>
      </Stack>
    </div>
  );
}
