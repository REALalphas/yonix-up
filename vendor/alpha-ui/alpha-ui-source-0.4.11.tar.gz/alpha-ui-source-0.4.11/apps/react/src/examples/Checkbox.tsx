// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, Checkbox, Text } from '@alpha/react';
export function CheckboxExample() {
  const [state, setState] = useState({ checked: false });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Checkbox
          id="choice"
          label="Сохранить выбор для следующих сеансов и других открытых окон"
          checked={state.checked}
          onCheckedChange={(checked) => update({ checked })}
        />
        <Text>{state.checked ? 'Выбрано' : 'Не выбрано'}</Text>
        <Checkbox id="disabled-choice" label="Недоступный вариант" checked={false} disabled />
      </Stack>
    </div>
  );
}
