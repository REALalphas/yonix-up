// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { useState } from 'react';
import { Stack, NavButton, Button, Text } from '@alpha/react';
export function BadgeExample() {
  const [state, setState] = useState({ count: 3, selected: false });
  const update = (patch: Partial<typeof state>) =>
    setState((previous) => ({ ...previous, ...patch }));

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Stack direction="row" align="start" gap={4}>
          <NavButton
            label="Чат"
            icon="messageReply"
            notifications={state.count > 99 ? '99+' : state.count}
            selected={state.selected}
            onPress={() => update({ selected: !state.selected })}
          />
        </Stack>
        <Stack direction="row" gap={3}>
          <Button onPress={() => update({ count: state.count + 1 })}>Добавить уведомление</Button>
          <Button variant="simple" onPress={() => update({ count: 100 })}>
            Показать 99+
          </Button>
        </Stack>
        <Text>Уведомлений: {state.count}</Text>
      </Stack>
    </div>
  );
}
