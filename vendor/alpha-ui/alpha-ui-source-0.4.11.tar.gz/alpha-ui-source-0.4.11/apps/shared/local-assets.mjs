import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

// Private test images are served only during local development, never copied to dist.
export function localDemoAssets(command) {
  const directory = fileURLToPath(new URL('./local-assets/', import.meta.url));
  const define = {};
  for (const number of [1, 2]) {
    const filename = `TestProfilePicture${number}.png`;
    const available = command === 'serve' && existsSync(join(directory, filename));
    define[`import.meta.env.ALPHA_TEST_PROFILE_PICTURE_${number}`] = available
      ? JSON.stringify(`/${filename}`)
      : 'undefined';
  }
  return { publicDir: command === 'serve' ? directory : false, define };
}
