import { defineConfig } from 'vite';
// CSR output is static; it does not need Qwik's SSR preview adapter.
export default defineConfig({ base: './' });
