import { defineConfig, loadEnv } from 'vite';
import { qwikVite } from '@builder.io/qwik/optimizer';
import { fileURLToPath } from 'node:url';
import { localDemoAssets } from '../shared/local-assets.mjs';
export default defineConfig(({ mode, command }) => ({
  ...localDemoAssets(command),
  base: loadEnv(mode, process.cwd(), 'VITE_').VITE_APP_BASE || './',
  ...(mode === 'docs-examples'
    ? {
        build: {
          outDir: 'dist-examples',
          rollupOptions: { input: fileURLToPath(new URL('./examples.html', import.meta.url)) },
        },
      }
    : {}),
  // Dev must optimize the adapter's TSX and lazy hooks, rather than its library MJS.
  resolve:
    command === 'serve'
      ? {
          alias: {
            '@alpha/qwik': fileURLToPath(
              new URL('../../packages/qwik/src/index.tsx', import.meta.url),
            ),
          },
        }
      : undefined,
  plugins: [qwikVite({ srcDir: 'src', csr: true, entryStrategy: { type: 'smart' } })],
}));
