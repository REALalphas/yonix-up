// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, NavButton, Text } from '@alpha/qwik';
export const NavButtonExample = component$(() => {
  const state = useStore({ selected: false });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <NavButton
          label="Чат"
          icon="messageReply"
          notifications="3"
          selected={state.selected}
          onPress$={() => update({ selected: !state.selected })}
        />
        <Text>{state.selected ? 'Выбрано' : 'Не выбрано'}</Text>
      </Stack>
    </div>
  );
});
