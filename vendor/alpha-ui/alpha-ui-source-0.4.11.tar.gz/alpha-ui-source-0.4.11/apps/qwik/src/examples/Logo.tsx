// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$ } from '@builder.io/qwik';
import { Stack, Logo } from '@alpha/qwik';
export const LogoExample = component$(() => {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Logo label="Alpha's UI" />
      </Stack>
    </div>
  );
});
