// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Card, Text, Button } from '@alpha/qwik';
export const CardExample = component$(() => {
  const state = useStore({ clicks: 0 });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Card>
          <Stack gap={4}>
            <Text as="h2">Карточка</Text>
            <Text>Нажатий: {state.clicks}</Text>
            <Button onPress$={() => update({ clicks: state.clicks + 1 })}>Действие</Button>
          </Stack>
        </Card>
      </Stack>
    </div>
  );
});
