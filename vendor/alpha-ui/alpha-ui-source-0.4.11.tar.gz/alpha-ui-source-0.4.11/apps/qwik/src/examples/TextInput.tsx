// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, TextInput, Text } from '@alpha/qwik';
export const TextInputExample = component$(() => {
  const state = useStore({ value: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <TextInput
          id="name"
          label="Название"
          value={state.value}
          hint="Введите название"
          onValueChange$={(value) => update({ value })}
        />
        <Text>Значение: {state.value || 'пусто'}</Text>
        <TextInput id="disabled-name" label="Недоступное поле" value="" disabled />
      </Stack>
    </div>
  );
});
