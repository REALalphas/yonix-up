// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Switch, Card, Text } from '@alpha/qwik';
export const StackExample = component$(() => {
  const state = useStore({ horizontal: false });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Switch
          id="direction"
          label="Горизонтальное направление"
          checked={state.horizontal}
          onCheckedChange$={(horizontal) => update({ horizontal })}
        />
        <Stack direction={state.horizontal ? 'row' : 'column'} gap={4}>
          <Card>
            <Text>Первый блок</Text>
          </Card>
          <Card>
            <Text>Второй блок</Text>
          </Card>
          <Card>
            <Text>Третий блок</Text>
          </Card>
        </Stack>
      </Stack>
    </div>
  );
});
