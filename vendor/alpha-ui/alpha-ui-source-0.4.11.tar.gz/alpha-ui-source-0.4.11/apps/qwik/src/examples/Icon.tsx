// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$ } from '@builder.io/qwik';
import { Stack, Icon, Text } from '@alpha/qwik';
export const IconExample = component$(() => {
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Stack direction="row" gap={4}>
          <Icon name="settings" label="Настройки" />
          <Icon name="settings" label="Настройки, bold" weight="bold" />
          <Icon name="search" label="Поиск" />
        </Stack>
        <Text>Regular — 1.5, bold — 2; размер — 24 × 24 при базе 16.</Text>
      </Stack>
    </div>
  );
});
