// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, ChatSurface, ChatThread, ChatMessage, Text } from '@alpha/qwik';
export const ChatMessageExample = component$(() => {
  const state = useStore({ favorite: false, notice: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <ChatThread>
            <ChatMessage
              text="Наведите курсор или перейдите к действиям клавишей Tab"
              favorite={state.favorite}
              onFavorite$={() => update({ favorite: !state.favorite })}
              onReply$={() => update({ notice: 'Выбрано действие «Ответить»' })}
            />
          </ChatThread>
        </ChatSurface>
        <Text>{state.favorite ? 'В избранном' : 'Не в избранном'}</Text>
        <Text>{state.notice}</Text>
      </Stack>
    </div>
  );
});
