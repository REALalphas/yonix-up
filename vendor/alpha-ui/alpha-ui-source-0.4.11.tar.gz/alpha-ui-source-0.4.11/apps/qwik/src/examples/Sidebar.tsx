// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Sidebar, Text, type NavItem } from '@alpha/qwik';
export const SidebarExample = component$(() => {
  const state = useStore({ selectedId: 'overview' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });
  const items: NavItem[] = [
    { id: 'overview', label: 'Обзор', icon: 'home' },
    { id: 'settings', label: 'Настройки', icon: 'settings' },
  ];
  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Sidebar
          items={items}
          selectedId={state.selectedId}
          onSelect$={(selectedId) => update({ selectedId })}
        />
        <Text>Выбрано: {state.selectedId}</Text>
      </Stack>
    </div>
  );
});
