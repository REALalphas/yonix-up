// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, ChatSurface, ChatButton, Text } from '@alpha/qwik';
export const ChatButtonExample = component$(() => {
  const state = useStore({ notice: '' });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <ChatSurface>
          <Stack direction="row" gap={3}>
            <ChatButton variant="emoji" onPress$={() => update({ notice: 'Emoji' })} />
            <ChatButton variant="attach" onPress$={() => update({ notice: 'Вложение' })} />
            <ChatButton variant="record" onPress$={() => update({ notice: 'Запись' })} />
            <ChatButton variant="send" onPress$={() => update({ notice: 'Отправка' })} />
          </Stack>
        </ChatSurface>
        <Text>{state.notice || 'Выберите действие'}</Text>
      </Stack>
    </div>
  );
});
