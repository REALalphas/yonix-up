// Generated from source/docs/examples.mjs. Run npm run generate; do not edit.
import { component$, useStore, $ } from '@builder.io/qwik';
import { Stack, Switch, Text } from '@alpha/qwik';
export const SwitchExample = component$(() => {
  const state = useStore({ checked: false });
  const update = $((patch: Partial<typeof state>) => {
    Object.assign(state, patch);
  });

  return (
    <div className="alpha-ui">
      <Stack gap={4}>
        <Switch
          id="notifications"
          label="Уведомления"
          checked={state.checked}
          onCheckedChange$={(checked) => update({ checked })}
        />
        <Text>{state.checked ? 'Включены' : 'Выключены'}</Text>
        <Switch
          id="disabled-notifications"
          label="Недоступный переключатель"
          checked={false}
          disabled
        />
      </Stack>
    </div>
  );
});
