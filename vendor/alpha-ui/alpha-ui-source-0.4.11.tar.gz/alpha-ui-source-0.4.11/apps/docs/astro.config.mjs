import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';
import { fileURLToPath } from 'node:url';
import { components } from '../../source/components/index.mjs';
import { docsBase, groups } from '../../scripts/lib/docs-site.mjs';

const base = docsBase(process.env.DOCS_BASE_PATH);

export default defineConfig({
  site: process.env.DOCS_SITE_URL || undefined,
  base,
  trailingSlash: 'always',
  vite: {
    plugins: [
      {
        name: 'alpha-docs-lucide-icons',
        enforce: 'pre',
        resolveId(source, importer) {
          if (importer?.includes('/@astrojs/starlight/') && /(?:^|\/)Icon\.astro$/.test(source)) {
            return fileURLToPath(new URL('./src/components/DocsIcon.astro', import.meta.url));
          }
        },
      },
    ],
  },
  integrations: [
    starlight({
      title: "Alpha's UI",
      description: 'Библиотека интерфейса React и Qwik. Один источник, два фреймворка.',
      defaultLocale: 'root',
      locales: { root: { label: 'Русский', lang: 'ru' } },
      customCss: ['./src/styles/docs.css'],
      credits: false,
      tableOfContents: false,
      components: {
        Header: './src/components/Header.astro',
        Sidebar: './src/components/Sidebar.astro',
        PageTitle: './src/components/PageTitle.astro',
        ThemeSelect: './src/components/Empty.astro',
        ThemeProvider: './src/components/ThemeProvider.astro',
      },
      expressiveCode: {
        themes: ['github-dark'],
        styleOverrides: {
          codeFontFamily: 'var(--as-font-mono)',
          codeFontSize: '1rem',
          borderRadius: 'var(--as-radius-card)',
          borderColor: 'transparent',
        },
      },
      sidebar: [
        { label: 'Обзор', slug: '' },
        {
          label: 'Начало работы',
          collapsed: true,
          items: [
            { label: 'Подключение', slug: 'guides/agent-guide' },
            { label: 'Установка и обновления', slug: 'guides/distribution' },
            { label: 'Правила для приложения', slug: 'guides/consumer-agent-rules' },
          ],
        },
        ...Object.entries(groups).map(([group, label]) => ({
          label,
          collapsed: true,
          items: components
            .filter((component) => component.group === group)
            .map(({ name }) => ({ label: name, slug: `components/${name.toLowerCase()}` })),
        })),
        {
          label: 'Поведение',
          collapsed: true,
          items: [
            { label: 'Кнопки', slug: 'guides/buttons' },
            { label: 'Поля и выбор', slug: 'guides/forms' },
            { label: 'Иконки', slug: 'guides/icons' },
            { label: 'Чат', slug: 'guides/chat' },
            { label: 'Движение', slug: 'guides/motion' },
            { label: 'Контейнеры Qwik', slug: 'guides/qwik-containers' },
          ],
        },
        {
          label: 'Разработка',
          collapsed: true,
          items: [
            { label: 'Проверка', slug: 'guides/verification' },
            { label: 'Сайт документации', slug: 'guides/documentation' },
            { label: 'Условия использования', slug: 'legal' },
          ],
        },
      ],
    }),
  ],
});
