import { installSelectOverlay } from './select-overlay.js';
import { installFieldResize } from './field-resize.js';
import { installFieldScrollbar } from './field-scrollbar.js';
import { installLoadingFrames } from './loading-frame.js';
import { motionTime } from './motion-timing.js';

export type ViewTransitionHandle = {
  ready: Promise<void>;
  updateCallbackDone: Promise<void>;
  finished: Promise<void>;
  skipTransition(): void;
};
export type TransitionDocument = {
  startViewTransition?: (update: () => void | Promise<void>) => ViewTransitionHandle;
  defaultView?: { matchMedia(query: string): { matches: boolean } } | null;
};
const active = new WeakMap<TransitionDocument, ViewTransitionHandle>();

/** The callback must resolve after the framework commits its DOM update. */
export async function transitionView(
  update: () => void | Promise<void>,
  options: {
    document?: TransitionDocument | null;
    reducedMotion?: boolean;
    onState?: (
      state: 'unsupported' | 'reduced' | 'started' | 'ready' | 'finished' | 'skipped',
    ) => void;
  } = {},
): Promise<void> {
  const doc =
    options.document === undefined
      ? typeof document === 'undefined'
        ? null
        : document
      : options.document;
  const reduced =
    options.reducedMotion ??
    doc?.defaultView?.matchMedia('(prefers-reduced-motion: reduce)').matches ??
    false;
  if (!doc?.startViewTransition || reduced) {
    options.onState?.(reduced ? 'reduced' : 'unsupported');
    await update();
    return;
  }
  // A new navigation replaces the animation, never the pending state commit.
  const previous = active.get(doc);
  previous?.skipTransition();
  if (previous) await previous.updateCallbackDone.catch(() => {});
  const handle = doc.startViewTransition(update);
  options.onState?.('started');
  active.set(doc, handle);
  // Skipped snapshots reject ready; callback errors still propagate below.
  void handle.ready.then(
    () => options.onState?.('ready'),
    () => options.onState?.('skipped'),
  );
  void handle.finished.then(
    () => options.onState?.('finished'),
    () => {},
  );
  void handle.finished
    .catch(() => {})
    .finally(() => {
      if (active.get(doc) === handle) active.delete(doc);
    });
  await handle.updateCallbackDone;
}

/** Delegated pointer/keyboard release timing. Call once per application root. */
export function installControlMotion(root: Document | HTMLElement = document): () => void {
  const disposeSelectOverlay = installSelectOverlay(root);
  const disposeResize = installFieldResize(root);
  const disposeScrollbar = installFieldScrollbar(root);
  const disposeLoading = installLoadingFrames(root);
  const timers = new Map<HTMLElement, ReturnType<typeof setTimeout>>();
  const pressedAt = new Map<HTMLElement, number>();
  const control = (event: Event) =>
    event.target instanceof Element
      ? (event.target.closest<HTMLElement>(
          '.alpha-ui .as-field-input-wrap[data-has-marker=true], .as-shell .as-field-input-wrap[data-has-marker=true], .alpha-ui .as-field-input-wrap[data-multiline=true], .as-shell .as-field-input-wrap[data-multiline=true]',
        ) ??
        event.target.closest<HTMLElement>(
          '.alpha-ui button, .as-shell button, .alpha-ui .as-field-control, .as-shell .as-field-control',
        ))
      : null;
  const clear = (element: HTMLElement) => {
    clearTimeout(timers.get(element));
    timers.delete(element);
    element.removeAttribute('data-as-release');
    element.removeAttribute('data-as-pressed');
    pressedAt.delete(element);
  };
  const release = (el: HTMLElement) => {
    const started = pressedAt.get(el);
    if (started === undefined) return;
    const finish = () => {
      clear(el);
      el.setAttribute('data-as-release', '');
      timers.set(
        el,
        setTimeout(
          () => clear(el),
          el.matches('.as-profile') ? 600 : motionTime(el, '--as-motion-fast'),
        ),
      );
    };
    const remaining = el.matches('.as-profile')
      ? 0
      : Math.max(0, motionTime(el, '--as-motion-interaction') - (performance.now() - started));
    clearTimeout(timers.get(el));
    timers.set(el, setTimeout(finish, remaining));
  };
  const down = (event: Event) => {
    if (
      event.target instanceof Element &&
      event.target.closest('.as-field-resize, .as-field-scrollbar')
    )
      return;
    if (
      event instanceof PointerEvent &&
      event.button === 0 &&
      event.target instanceof Element &&
      event.target.matches('.as-field-input-wrap[data-multiline=true]')
    ) {
      const field = event.target.querySelector<HTMLTextAreaElement>('.as-textarea');
      if (field && !field.disabled) {
        event.preventDefault();
        field.focus({ preventScroll: true });
      }
    }
    if (event instanceof KeyboardEvent && (!['Enter', ' '].includes(event.key) || event.repeat))
      return;
    const el = control(event);
    if (
      !el ||
      el.matches('select') ||
      el.matches(
        ':disabled, .as-nav-button[data-selected=true], .as-drawer-button[data-selected=true]',
      )
    )
      return;
    if (
      event instanceof KeyboardEvent &&
      (el.matches('.as-field-control') ||
        (el.matches('.as-field-input-wrap') && !el.hasAttribute('tabindex')))
    )
      return;
    if (el.matches('.as-field-input-wrap') && event instanceof KeyboardEvent)
      event.preventDefault();
    clear(el);
    pressedAt.set(el, performance.now());
    if (el.matches('.as-profile'))
      timers.set(
        el,
        setTimeout(() => {
          timers.delete(el);
          el.setAttribute('data-as-pressed', '');
        }, 100),
      );
    else el.setAttribute('data-as-pressed', '');
  };
  const up = (event: Event) => {
    if (event instanceof KeyboardEvent && !['Enter', ' '].includes(event.key)) return;
    const el = control(event);
    if (!el || el.matches('select') || el.matches(':disabled')) return;
    if (
      event instanceof KeyboardEvent &&
      (el.matches('.as-field-control') ||
        (el.matches('.as-field-input-wrap') && !el.hasAttribute('tabindex')))
    )
      return;
    release(el);
  };
  const out = (event: Event) => {
    const el = control(event);
    if (
      el &&
      !el.matches('select') &&
      (!(event instanceof PointerEvent) || !el.contains(event.relatedTarget as Node | null))
    )
      clear(el);
  };
  const listeners: [string, EventListener][] = [
    ['pointerdown', down],
    ['pointerup', up],
    ['keydown', down],
    ['keyup', up],
    ['pointerout', out],
    ['pointercancel', out],
    ['focusout', out],
  ];
  for (const [name, handler] of listeners) root.addEventListener(name, handler, true);
  return () => {
    disposeSelectOverlay();
    disposeLoading();
    disposeScrollbar();
    disposeResize();
    for (const [name, handler] of listeners) root.removeEventListener(name, handler, true);
    for (const el of new Set([...timers.keys(), ...pressedAt.keys()])) clear(el);
  };
}

/** Observe a real Qwik DOM commit instead of guessing with a delay. */
export function waitForViewCommit(
  element: Element,
  attribute: string,
  value: string,
): Promise<void> {
  if (element.getAttribute(attribute) === value) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const observer = new MutationObserver(() => {
      if (element.getAttribute(attribute) === value) {
        observer.disconnect();
        clearTimeout(timeout);
        resolve();
      }
    });
    const timeout = setTimeout(() => {
      observer.disconnect();
      reject(new Error('View transition: DOM commit did not complete'));
    }, 5000);
    observer.observe(element, { attributes: true, attributeFilter: [attribute] });
  });
}
