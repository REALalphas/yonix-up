/** Read the same CSS time tokens that drive the control's transitions. */
export function motionTime(
  element: HTMLElement,
  token: '--as-motion-interaction' | '--as-motion-fast',
): number {
  const win = element.ownerDocument?.defaultView;
  if (!win || win.matchMedia('(prefers-reduced-motion: reduce)').matches) return 0;
  const value = win.getComputedStyle(element).getPropertyValue(token).trim();
  const time = /^([\d.]+)(ms|s)$/.exec(value);
  return time ? Number(time[1]) * (time[2] === 's' ? 1000 : 1) : 0;
}
