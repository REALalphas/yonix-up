/** The same dashed SVG contour as Profile, measured without stretching corners. */
export function loadingFramePath(
  width: number,
  height: number,
  radius: number,
  stroke: number,
  curvature: number,
): string {
  const inset = stroke / 2,
    r = Math.max(0, Math.min(radius, width / 2, height / 2) - inset);
  const power = 2 / 2 ** curvature;
  const centers = [
    [width - inset - r, inset + r],
    [width - inset - r, height - inset - r],
    [inset + r, height - inset - r],
    [inset + r, inset + r],
  ];
  const points: string[] = [];
  for (let corner = 0; corner < 4; corner++)
    for (let step = 0; step <= 64; step++) {
      const angle = ((corner - 1) * Math.PI) / 2 + (step * Math.PI) / 128;
      const cos = Math.cos(angle),
        sin = Math.sin(angle);
      const x = centers[corner][0] + r * Math.sign(cos) * Math.abs(cos) ** power;
      const y = centers[corner][1] + r * Math.sign(sin) * Math.abs(sin) ** power;
      points.push(`${points.length ? 'L' : 'M'}${x.toFixed(5)} ${y.toFixed(5)}`);
    }
  return points.join(' ') + ' Z';
}

export function installLoadingFrames(root: Document | HTMLElement): () => void {
  if (typeof root.querySelectorAll !== 'function') return () => {};
  const doc = root.nodeType === 9 ? (root as Document) : root.ownerDocument!;
  const view = doc.defaultView!;
  const buttons = new Set<HTMLButtonElement>();
  let frame = 0,
    disposed = false;
  const update = (button: HTMLButtonElement) => {
    const svg = button.querySelector<SVGSVGElement>('.as-button-frame');
    if (!svg || !button.clientWidth || !button.clientHeight) return;
    const css = view.getComputedStyle(button);
    const stroke =
      parseFloat(css.getPropertyValue('--as-borderwidth-loading')) *
      parseFloat(view.getComputedStyle(doc.documentElement).fontSize);
    const strokeValue = `${stroke}px`;
    if (svg.style.getPropertyValue('--as-loading-stroke') !== strokeValue)
      svg.style.setProperty('--as-loading-stroke', strokeValue);
    const path = loadingFramePath(
      button.getBoundingClientRect().width,
      button.getBoundingClientRect().height,
      parseFloat(css.borderTopRightRadius),
      stroke,
      view.CSS.supports('corner-shape', 'superellipse(1.2)') ? 1.2 : 1,
    );
    const shape = svg.querySelector('path')!;
    if (shape.getAttribute('d') !== path) shape.setAttribute('d', path);
    svg.setAttribute('data-ready', '');
  };
  const resize = new ResizeObserver((entries) => {
    for (const entry of entries) update(entry.target as HTMLButtonElement);
  });
  const scan = () => {
    frame = 0;
    for (const button of root.querySelectorAll<HTMLButtonElement>('.as-button:disabled')) {
      if (!buttons.has(button)) {
        buttons.add(button);
        resize.observe(button);
      }
      update(button);
    }
    for (const button of buttons)
      if (!button.isConnected || !button.disabled) {
        resize.unobserve(button);
        buttons.delete(button);
      }
  };
  const schedule = () => {
    if (!disposed && !frame) frame = view.requestAnimationFrame(scan);
  };
  const observer = new MutationObserver(schedule);
  observer.observe(root, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'data-loading', 'data-size', 'disabled'],
  });
  view.addEventListener('resize', schedule);
  scan();
  return () => {
    disposed = true;
    observer.disconnect();
    resize.disconnect();
    view.removeEventListener('resize', schedule);
    if (frame) view.cancelAnimationFrame(frame);
    buttons.clear();
  };
}
