import { motionTime } from './motion-timing.js';

/** Select-specific press handling; ordinary inputs retain their original lifecycle. */
export function installSelectMotion(root: Document | HTMLElement): () => void {
  const doc = root.nodeType === 9 ? (root as Document) : root.ownerDocument;
  if (!doc?.defaultView) return () => {};
  const timers = new Map<HTMLSelectElement, ReturnType<typeof setTimeout>>();
  const started = new Map<HTMLSelectElement, number>();
  const focused = new Set<HTMLSelectElement>();
  const selectAt = (event: Event) =>
    event.target instanceof Element
      ? event.target.closest<HTMLSelectElement>('select.as-field-control')
      : null;
  const clear = (select: HTMLSelectElement) => {
    clearTimeout(timers.get(select));
    timers.delete(select);
    started.delete(select);
    select.removeAttribute('data-as-pressed');
    select.removeAttribute('data-as-release');
  };
  const release = (select: HTMLSelectElement) => {
    const time = started.get(select);
    if (time === undefined) return;
    clearTimeout(timers.get(select));
    timers.set(
      select,
      setTimeout(
        () => {
          clear(select);
          select.setAttribute('data-as-release', '');
          timers.set(
            select,
            setTimeout(() => clear(select), motionTime(select, '--as-motion-fast')),
          );
        },
        Math.max(0, motionTime(select, '--as-motion-interaction') - (performance.now() - time)),
      ),
    );
  };
  const down = (event: Event) => {
    if (event instanceof KeyboardEvent) {
      for (const select of focused) select.removeAttribute('data-as-pointer-focus');
      focused.clear();
      if (!['Enter', ' '].includes(event.key) || event.repeat) return;
    }
    const select = selectAt(event);
    if (!select || select.disabled) return;
    if (event instanceof PointerEvent) {
      if (event.button !== 0) return;
      select.setAttribute('data-as-pointer-focus', '');
      focused.add(select);
    }
    clear(select);
    started.set(select, performance.now());
    select.setAttribute('data-as-pressed', '');
    if (select.dataset.popup !== 'overlay') release(select);
  };
  const up = (event: Event) => {
    if (event instanceof KeyboardEvent && !['Enter', ' '].includes(event.key)) return;
    const select = selectAt(event);
    if (select) release(select);
  };
  const out = (event: Event) => {
    const select = selectAt(event);
    if (!select) return;
    if (event.type === 'focusout') {
      select.removeAttribute('data-as-pointer-focus');
      focused.delete(select);
    }
    release(select);
  };
  const listeners: [string, EventListener][] = [
    ['pointerdown', down],
    ['keydown', down],
    ['pointerup', up],
    ['keyup', up],
    ['pointerout', out],
    ['pointercancel', out],
    ['focusout', out],
  ];
  for (const [name, handler] of listeners) root.addEventListener(name, handler, true);
  return () => {
    for (const [name, handler] of listeners) root.removeEventListener(name, handler, true);
    for (const select of new Set([...timers.keys(), ...started.keys()])) clear(select);
    for (const select of focused) select.removeAttribute('data-as-pointer-focus');
    focused.clear();
  };
}
