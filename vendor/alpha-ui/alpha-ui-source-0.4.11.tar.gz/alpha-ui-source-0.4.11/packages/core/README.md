# @alpha/core

Shared runtime, styles, tokens, fonts and icons for Alpha's UI.

```js
import '@alpha/core/fonts.css';
import '@alpha/core/styles.css';
```

See the packaged guides, including `@alpha/core/distribution.md`.

Use components from `@alpha/react` or `@alpha/qwik` at the same version. Wrap ordinary components in `.alpha-ui`; `AppShell` creates its own shell.

In the browser, install shared control motion once:

```js
import { installControlMotion } from '@alpha/core';
const dispose = installControlMotion();
// Call dispose() when destroying the application. Do not install during SSR.
```

Read `@alpha/core/AGENTS.md` and `@alpha/core/agent-guide.md`.

Licensed under AHCL-1.0, a source-available license with conditions on commercial use and Hub integration. Read [LICENSE](./LICENSE) and [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md) before use. Corresponding source must accompany distribution or be available for the exact version as required by §4 of LICENSE.
