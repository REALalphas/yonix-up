// Generated from source/components/navigation/BottomNav.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { NavButton } from './NavButton';
export type BottomNavProps = CommonProps & {
  items: NavItem[];
  selectedId: string;
  label?: string;
  onSelect?: Handler<[id: string]>;
};
export function BottomNav(p: BottomNavProps) {
  return (
    <nav className={cx('as-bottom-nav', p.className)} aria-label={p.label ?? 'Service navigation'}>
      {p.items.map((item) => (
        <NavButton
          key={item.id}
          label={item.label}
          icon={item.icon}
          notifications={item.notifications}
          selected={item.id === p.selectedId}
          onPress={() => p.onSelect?.(item.id)}
        />
      ))}
    </nav>
  );
}
