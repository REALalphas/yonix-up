// Generated from source/components/foundation/Badge.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type BadgeProps = CommonProps & {
  value: string | number;
};
export function Badge(p: BadgeProps) {
  return (
    <span className={cx('as-badge', p.className)} aria-label={String(p.value) + ' notifications'}>
      <span className="as-badge-label" data-overflow={String(p.value) === '99+' || undefined}>
        {p.value}
      </span>
    </span>
  );
}
