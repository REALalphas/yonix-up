// Generated from source/components/navigation/Sidebar.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { DrawerButton } from './DrawerButton';
import { DrawerDivider } from './DrawerDivider';
export type SidebarProps = CommonProps & {
  items: NavItem[];
  selectedId: string;
  label?: string;
  onSelect?: Handler<[id: string]>;
};
export function Sidebar(p: SidebarProps) {
  return (
    <nav className={cx('as-sidebar', p.className)} aria-label={p.label ?? 'Service navigation'}>
      {p.items.map((item) => (
        <div key={item.id}>
          {item.group && <DrawerDivider label={item.group} />}
          <DrawerButton
            label={item.label}
            icon={item.icon}
            secondaryText={
              item.notifications === undefined ? undefined : String(item.notifications)
            }
            selected={item.id === p.selectedId}
            onPress={() => p.onSelect?.(item.id)}
          />
        </div>
      ))}
    </nav>
  );
}
