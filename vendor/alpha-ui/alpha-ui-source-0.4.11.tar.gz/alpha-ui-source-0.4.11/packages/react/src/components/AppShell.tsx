// Generated from source/components/layout/AppShell.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { HeadBar } from './HeadBar';
import { BottomNav } from './BottomNav';
import { Sidebar } from './Sidebar';
export type AppShellProps = CommonProps & {
  serviceValue?: string;
  serviceOptions?: { value: string; label: string; disabled?: boolean }[];
  serviceLabel?: string;
  serviceDisabled?: boolean;
  context?: {
    label: string;
    value: string;
    options: { value: string; label: string; disabled?: boolean }[];
    placeholder?: string;
    disabled?: boolean;
  };
  onServiceChange?: Handler<[value: string]>;
  onContextChange?: Handler<[value: string]>;
  serviceName: string;
  items: NavItem[];
  selectedId: string;
  width?: 'content' | 'container';
  accountSrc?: string;
  accountState?: 'default' | 'loading' | 'unstable' | 'error';
  balance?: string;
  onSelect?: Handler<[id: string]>;
  onServicePress?: Handler<[]>;
  onAccountPress?: Handler<[]>;
};
export function AppShell(p: AppShellProps) {
  return (
    <div className={cx('as-shell', p.className)} data-width={p.width ?? 'content'}>
      <HeadBar
        serviceValue={p.serviceValue}
        serviceOptions={p.serviceOptions}
        serviceLabel={p.serviceLabel}
        serviceDisabled={p.serviceDisabled}
        context={p.context}
        onServiceChange={p.onServiceChange}
        onContextChange={p.onContextChange}
        serviceName={p.serviceName}
        accountSrc={p.accountSrc}
        accountState={p.accountState}
        balance={p.balance}
        onServicePress={p.onServicePress}
        onAccountPress={p.onAccountPress}
      />
      <Sidebar items={p.items} selectedId={p.selectedId} onSelect={p.onSelect} />
      <main className="as-shell-content" id={p.id}>
        {p.children}
      </main>
      <BottomNav items={p.items} selectedId={p.selectedId} onSelect={p.onSelect} />
    </div>
  );
}
