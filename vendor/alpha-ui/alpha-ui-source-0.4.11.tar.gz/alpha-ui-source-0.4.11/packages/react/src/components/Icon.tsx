// Generated from source/components/foundation/Icon.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type IconProps = CommonProps & {
  name: IconName;
  label?: string;
  weight?: 'regular' | 'bold';
};
export function Icon(p: IconProps) {
  return (
    <span
      className={cx('as-icon', p.className)}
      data-icon-weight={p.weight}
      role={p.label ? 'img' : undefined}
      aria-label={p.label}
      aria-hidden={p.label ? undefined : true}
      style={
        {
          '--as-icon-regular-url': 'url("' + iconsRegular[p.name] + '")',
          '--as-icon-bold-url': 'url("' + icons[p.name] + '")',
        } as CSSProperties
      }
    />
  );
}
