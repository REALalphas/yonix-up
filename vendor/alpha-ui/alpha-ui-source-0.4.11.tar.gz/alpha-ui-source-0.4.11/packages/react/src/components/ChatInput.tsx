// Generated from source/components/chat/ChatInput.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { ChatButton } from './ChatButton';
export type ChatInputProps = CommonProps & {
  value: string;
  disabled?: boolean;
  placeholder?: string;
  onValueChange?: Handler<[string]>;
  onEmoji?: Handler<[]>;
};
export function ChatInput(p: ChatInputProps) {
  return (
    <div className={cx('as-chat-input-surface', p.className)}>
      {p.onEmoji && <ChatButton variant="emoji" disabled={p.disabled} onPress={p.onEmoji} />}
      <textarea
        className="as-chat-input"
        aria-label="Сообщение"
        placeholder={p.placeholder ?? 'Напиши сообщение…'}
        rows={1}
        value={p.value}
        disabled={p.disabled}
        onChange={(e) => p.onValueChange?.(e.currentTarget.value)}
      />
      <div className="as-chat-input-actions">{p.children}</div>
    </div>
  );
}
