// Generated from source/components/controls/Checkbox.mjs. Run npm run generate; do not edit.
import { useRef, useEffect, useState, useId, type ReactNode, type CSSProperties } from 'react';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = (...args: T) => void;
type Children = ReactNode;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
export type CheckboxProps = CommonProps & {
  id: string;
  label: string;
  checked: boolean;
  name?: string;
  value?: string;
  disabled?: boolean;
  required?: boolean;
  hint?: string;
  onCheckedChange?: Handler<[checked: boolean]>;
};
export function Checkbox(p: CheckboxProps) {
  return (
    <div className={cx('as-choice', p.className)} data-disabled={p.disabled ? 'true' : 'false'}>
      <label className="as-choice-label">
        <input
          className="as-choice-input as-sr-only"
          id={p.id}
          type="checkbox"
          name={p.name}
          value={p.value}
          checked={p.checked}
          disabled={p.disabled}
          required={p.required}
          aria-describedby={p.hint ? p.id + '-description' : undefined}
          onChange={(e) => p.onCheckedChange?.(e.currentTarget.checked)}
        />
        <span className="as-choice-control as-checkbox" aria-hidden="true">
          <Icon name="check" weight="regular" />
        </span>
        <span className="as-choice-text">{p.label}</span>
      </label>
      {p.hint && (
        <span id={p.id + '-description'} className="as-field-description">
          {p.hint}
        </span>
      )}
    </div>
  );
}
