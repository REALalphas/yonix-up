// Generated from source/components/navigation/DrawerButton.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
export type DrawerButtonProps = CommonProps & {
  label: string;
  icon?: IconName;
  secondaryText?: string;
  secondaryPlacement?: 'inline' | 'below';
  selected?: boolean;
  onPress$?: Handler<[]>;
};
export const DrawerButton = component$<DrawerButtonProps>((p) => {
  return (
    <button
      type="button"
      className={cx('as-drawer-button', p.className)}
      data-secondary-placement={p.secondaryPlacement ?? 'inline'}
      data-selected={p.selected ? 'true' : 'false'}
      aria-current={p.selected ? 'page' : undefined}
      onClick$={p.onPress$}
    >
      <Icon name={p.icon ?? 'key'} weight={p.selected ? 'bold' : 'regular'} />
      <span className="as-drawer-label">{p.label}</span>
      {p.secondaryText && <span className="as-drawer-secondary">{p.secondaryText}</span>}
    </button>
  );
});
