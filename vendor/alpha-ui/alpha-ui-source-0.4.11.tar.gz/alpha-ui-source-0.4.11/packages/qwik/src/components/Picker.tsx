// Generated from source/components/controls/Picker.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Select } from './Select';
export type PickerProps = CommonProps & {
  label: string;
  value: string;
  options: { value: string; label: string; disabled?: boolean }[];
  placeholder?: string;
  disabled?: boolean;
  variant?: 'plain' | 'service';
  popup?: 'native' | 'overlay';
  onValueChange$?: Handler<[value: string]>;
};
export const Picker = component$<PickerProps>((p) => {
  const generatedId = useId();
  const pickerId = p.id ?? 'as-picker-' + generatedId;
  const knownValue = p.options.some((option) => option.value === p.value);
  return (
    <Select
      id={pickerId}
      className={cx('as-picker', p.className)}
      label={p.label}
      value={knownValue ? p.value : ''}
      options={p.options}
      placeholder={p.placeholder ?? 'Не выбрано'}
      disabled={p.disabled || !p.options.some((option) => !option.disabled)}
      variant={p.variant ?? 'plain'}
      popup={p.popup ?? (p.variant === 'service' ? 'native' : 'overlay')}
      onValueChange$={p.onValueChange$}
    />
  );
});
