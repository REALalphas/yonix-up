// Generated from source/components/chat/ChatMessage.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Text } from './Text';
import { ChatButton } from './ChatButton';
export type ChatMessageProps = CommonProps & {
  author?: string;
  text: string;
  time?: string;
  timestamp?: number;
  outgoing?: boolean;
  favorite?: boolean;
  onFavorite$?: Handler<[]>;
  onReply$?: Handler<[]>;
  onEdit$?: Handler<[]>;
  onDownload$?: Handler<[]>;
  onForward$?: Handler<[]>;
};
export const ChatMessage = component$<ChatMessageProps>((p) => {
  const chatNow = useSignal(Date.now());
  useVisibleTask$(
    ({ track, cleanup }) => {
      const timestamp = track(() => p.timestamp);
      if (timestamp === undefined) return;
      chatNow.value = Date.now();
      const timer = setInterval(() => {
        chatNow.value = Date.now();
      }, 1000);
      cleanup(() => clearInterval(timer));
    },
    { strategy: 'document-ready' },
  );
  const hasTimestamp = p.timestamp !== undefined && Number.isFinite(p.timestamp);
  const timeLabel = hasTimestamp ? formatChatTime(p.timestamp!, chatNow.value) : p.time;
  const hasActions = !!(
    p.onReply$ || (p.outgoing ? p.onFavorite$ || p.onEdit$ : p.onDownload$ || p.onForward$)
  );
  return (
    <div
      className={cx('as-chat-message-row', p.className)}
      data-outgoing={p.outgoing ? 'true' : undefined}
      data-timestamp={p.timestamp}
      data-author={p.author}
      tabIndex={hasActions ? 0 : undefined}
    >
      <article
        className="as-chat-message"
        data-outgoing={p.outgoing ? 'true' : undefined}
        aria-label={p.author}
      >
        <Text className="as-chat-message-text">{p.text}</Text>
        {timeLabel && (
          <time
            className="as-text as-chat-message-time"
            data-tone="secondary"
            dateTime={hasTimestamp ? new Date(p.timestamp!).toISOString() : undefined}
            title={hasTimestamp ? new Date(p.timestamp!).toLocaleString('ru-RU') : undefined}
          >
            {timeLabel}
          </time>
        )}
      </article>
      {hasActions && (
        <div className={'as-chat-message-actions'} aria-label="Действия сообщения">
          {p.outgoing && p.onFavorite$ && (
            <ChatButton
              icon="favorite"
              label={p.favorite ? 'Убрать из избранного' : 'В избранное'}
              pressed={p.favorite}
              onPress$={p.onFavorite$}
            />
          )}
          {p.outgoing && p.onEdit$ && (
            <ChatButton icon="edit" label="Редактировать" onPress$={p.onEdit$} />
          )}
          {p.onReply$ && <ChatButton icon="messageReply" label="Ответить" onPress$={p.onReply$} />}
          {!p.outgoing && p.onDownload$ && (
            <ChatButton icon="downloadFile" label="Скачать" onPress$={p.onDownload$} />
          )}
          {!p.outgoing && p.onForward$ && (
            <ChatButton icon="forward" label="Переслать" onPress$={p.onForward$} />
          )}
        </div>
      )}
    </div>
  );
});
