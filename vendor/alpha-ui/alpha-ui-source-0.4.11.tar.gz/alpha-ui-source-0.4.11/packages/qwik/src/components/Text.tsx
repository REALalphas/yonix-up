// Generated from source/components/foundation/Text.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };

export type TextProps = CommonProps & {
  as?: 'p' | 'span' | 'h1' | 'h2' | 'h3';
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'title' | 'heading';
  tone?: 'default' | 'secondary' | 'muted';
  font?: 'ui' | 'heading' | 'support' | 'mono';
  weight?: 'regular' | 'medium' | 'bold';
};
export const Text = component$<TextProps>((p) => {
  const Tag = p.as ?? 'p';
  const heading = Tag === 'h1' || Tag === 'h2' || Tag === 'h3';
  return (
    <Tag
      className={cx('as-text', p.className)}
      data-size={p.size ?? (heading ? 'title' : 'md')}
      data-tone={p.tone ?? 'default'}
      data-font={p.font ?? (heading ? 'heading' : 'ui')}
      data-weight={p.weight ?? (heading ? 'bold' : 'regular')}
    >
      <Slot />
    </Tag>
  );
});
