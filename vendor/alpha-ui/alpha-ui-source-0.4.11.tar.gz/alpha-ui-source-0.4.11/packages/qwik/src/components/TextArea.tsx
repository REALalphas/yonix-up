// Generated from source/components/controls/TextArea.mjs. Run npm run generate; do not edit.
import {
  component$,
  Slot,
  useSignal,
  useId,
  useVisibleTask$,
  type QRL,
  type JSXChildren,
} from '@builder.io/qwik';
import {
  assets,
  icons,
  iconsRegular,
  cx,
  clamp,
  formatTime,
  formatChatTime,
  installChatGradient,
  installChatGrouping,
  type AssetName,
  type IconName,
} from '@alpha/core';
export { assets, icons } from '@alpha/core';
type Handler<T extends unknown[]> = QRL<(...args: T) => void>;
type Children = JSXChildren;
export type NavItem = {
  id: string;
  label: string;
  icon?: IconName;
  notifications?: string | number;
  group?: string;
};
type CommonProps = { className?: string; id?: string; children?: Children };
import { Icon } from './Icon';
export type TextAreaProps = CommonProps & {
  id: string;
  label: string;
  labelPlacement?: 'inside' | 'above';
  icon?: IconName;
  showIcon?: boolean;
  value: string;
  name?: string;
  placeholder?: string;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  hint?: string;
  error?: string;
  onValueChange$?: Handler<[value: string]>;
  rows?: number;
  resize?: 'vertical' | 'both';
};
export const TextArea = component$<TextAreaProps>((p) => {
  const fieldIcon = p.icon ?? 'type';
  const hasMarker = p.showIcon ?? (!!p.readOnly || !!p.disabled);
  const labelAbove =
    p.labelPlacement === 'above' || (p.labelPlacement !== 'inside' && !!(p.readOnly || p.disabled));
  return (
    <div
      className={cx('as-field as-placeholder-field', p.className)}
      data-disabled={p.disabled ? 'true' : 'false'}
      data-error={p.error ? 'true' : 'false'}
      data-label-placement={labelAbove ? 'above' : 'inside'}
    >
      {labelAbove && (
        <label className="as-field-label" for={p.id}>
          {p.label}
        </label>
      )}
      <span
        className="as-field-input-wrap"
        data-has-value={p.value.length ? 'true' : 'false'}
        data-has-marker={hasMarker ? 'true' : 'false'}
        data-multiline="true"
        tabIndex={p.disabled ? 0 : undefined}
        role={p.disabled ? 'button' : undefined}
        aria-label={p.disabled ? 'Редактирование недоступно: ' + p.label : undefined}
      >
        <textarea
          className="as-field-control as-textarea"
          id={p.id}
          name={p.name}
          value={p.value}
          disabled={p.disabled}
          required={p.required}
          aria-label={labelAbove ? undefined : p.label}
          aria-invalid={!!p.error || undefined}
          aria-describedby={p.error || p.hint ? p.id + '-description' : undefined}
          placeholder={labelAbove ? p.placeholder : undefined}
          readOnly={p.readOnly}
          rows={p.rows ?? 4}
          onInput$={(_, el) => p.onValueChange$?.(el.value)}
        />
        {!labelAbove && (
          <span className="as-field-placeholder" aria-hidden="true">
            <span className="as-field-placeholder-text">{p.placeholder ?? p.label}</span>
          </span>
        )}
        <span
          className="as-field-scrollbar"
          role="scrollbar"
          aria-orientation="vertical"
          aria-label={'Прокрутить: ' + p.label}
          aria-controls={p.id}
          tabIndex={0}
          hidden
        >
          <svg aria-hidden="true">
            <path class="as-field-scrollbar-hit" />
            <path class="as-field-scrollbar-thumb" />
          </svg>
        </span>
        <span
          className="as-field-resize"
          data-resize-axis={p.resize ?? 'vertical'}
          data-resize-handle={p.resize === 'both' ? 'corner' : 'bottom'}
          role={p.resize === 'both' ? 'button' : 'separator'}
          aria-orientation={p.resize === 'both' ? undefined : 'horizontal'}
          aria-label={(p.resize === 'both' ? 'Изменить размер: ' : 'Изменить высоту: ') + p.label}
          aria-controls={p.id}
          tabIndex={0}
        >
          {p.resize === 'both' && (
            <svg
              class="as-field-resize-arc"
              viewBox="0 0 30 30"
              style={{
                ['--as-corner-idle' as string]:
                  'path("M26.25000 15.00000 L26.24672 15.50120 L26.23709 15.90381 L26.22126 16.27396 L26.19936 16.62363 L26.17146 16.95815 L26.13766 17.28052 L26.09803 17.59263 L26.05264 17.89574 L26.00156 18.19077 L25.94486 18.47838 L25.88261 18.75908 L25.81488 19.03328 L25.74172 19.30127 L25.66321 19.56331 L25.57940 19.81960 L25.49036 20.07032 L25.39615 20.31559 L25.29681 20.55554 L25.19241 20.79026 L25.08300 21.01984 L24.96863 21.24435 L24.84933 21.46386 L24.72516 21.67842 L24.59614 21.88808 L24.46233 22.09288 L24.32373 22.29287 L24.18038 22.48806 L24.03231 22.67849 L23.87952 22.86417 L23.72203 23.04514 L23.55984 23.22141 L23.39297 23.39297 L23.22141 23.55984 L23.04514 23.72203 L22.86417 23.87952 L22.67849 24.03231 L22.48806 24.18038 L22.29287 24.32373 L22.09288 24.46233 L21.88808 24.59614 L21.67842 24.72516 L21.46386 24.84933 L21.24435 24.96863 L21.01984 25.08300 L20.79026 25.19241 L20.55554 25.29681 L20.31559 25.39615 L20.07032 25.49036 L19.81960 25.57940 L19.56331 25.66321 L19.30127 25.74172 L19.03328 25.81488 L18.75908 25.88261 L18.47838 25.94486 L18.19077 26.00156 L17.89574 26.05264 L17.59263 26.09803 L17.28052 26.13766 L16.95815 26.17146 L16.62363 26.19936 L16.27396 26.22126 L15.90381 26.23709 L15.50120 26.24672 L15.00000 26.25000")',
                ['--as-corner-active' as string]:
                  'path("M22.50000 15.00000 L22.49737 15.40753 L22.48990 15.72028 L22.47791 16.00100 L22.46161 16.26130 L22.44118 16.50644 L22.41676 16.73939 L22.38849 16.96203 L22.35650 17.17567 L22.32091 17.38127 L22.28183 17.57953 L22.23937 17.77101 L22.19364 17.95618 L22.14472 18.13540 L22.09271 18.30899 L22.03770 18.47723 L21.97977 18.64035 L21.91900 18.79857 L21.85544 18.95209 L21.78918 19.10109 L21.72025 19.24573 L21.64870 19.38617 L21.57458 19.52257 L21.49790 19.65507 L21.41868 19.78381 L21.33694 19.90891 L21.25267 20.03050 L21.16587 20.14871 L21.07650 20.26364 L20.98454 20.37540 L20.88995 20.48410 L20.79267 20.58982 L20.69265 20.69265 L20.58982 20.79267 L20.48410 20.88995 L20.37540 20.98454 L20.26364 21.07650 L20.14871 21.16587 L20.03050 21.25267 L19.90891 21.33694 L19.78381 21.41868 L19.65507 21.49790 L19.52257 21.57458 L19.38617 21.64870 L19.24573 21.72025 L19.10109 21.78918 L18.95209 21.85544 L18.79857 21.91900 L18.64035 21.97977 L18.47723 22.03770 L18.30899 22.09271 L18.13540 22.14472 L17.95618 22.19364 L17.77101 22.23937 L17.57953 22.28183 L17.38127 22.32091 L17.17567 22.35650 L16.96203 22.38849 L16.73939 22.41676 L16.50644 22.44118 L16.26130 22.46161 L16.00100 22.47791 L15.72028 22.48990 L15.40753 22.49737 L15.00000 22.50000")',
                ['--as-corner-round-idle' as string]:
                  'path("M26.25000 15.00000 L26.24661 15.27609 L26.23645 15.55201 L26.21952 15.82760 L26.19583 16.10269 L26.16539 16.37712 L26.12824 16.65072 L26.08437 16.92332 L26.03383 17.19477 L25.97665 17.46489 L25.91285 17.73353 L25.84248 18.00052 L25.76558 18.26570 L25.68219 18.52892 L25.59237 18.79001 L25.49617 19.04882 L25.39364 19.30519 L25.28486 19.55896 L25.16988 19.80999 L25.04877 20.05813 L24.92161 20.30321 L24.78848 20.54510 L24.64945 20.78366 L24.50460 21.01872 L24.35403 21.25017 L24.19783 21.47784 L24.03608 21.70162 L23.86890 21.92136 L23.69637 22.13692 L23.51860 22.34819 L23.33570 22.55504 L23.14778 22.75733 L22.95495 22.95495 L22.75733 23.14778 L22.55504 23.33570 L22.34819 23.51860 L22.13692 23.69637 L21.92136 23.86890 L21.70162 24.03608 L21.47784 24.19783 L21.25017 24.35403 L21.01872 24.50460 L20.78366 24.64945 L20.54510 24.78848 L20.30321 24.92161 L20.05813 25.04877 L19.80999 25.16988 L19.55896 25.28486 L19.30519 25.39364 L19.04882 25.49617 L18.79001 25.59237 L18.52892 25.68219 L18.26570 25.76558 L18.00052 25.84248 L17.73353 25.91285 L17.46489 25.97665 L17.19477 26.03383 L16.92332 26.08437 L16.65072 26.12824 L16.37712 26.16539 L16.10269 26.19583 L15.82760 26.21952 L15.55201 26.23645 L15.27609 26.24661 L15.00000 26.25000")',
                ['--as-corner-round-active' as string]:
                  'path("M22.50000 15.00000 L22.49774 15.18406 L22.49097 15.36801 L22.47968 15.55173 L22.46389 15.73513 L22.44360 15.91808 L22.41882 16.10048 L22.38958 16.28221 L22.35589 16.46318 L22.31777 16.64326 L22.27523 16.82235 L22.22832 17.00035 L22.17705 17.17714 L22.12146 17.35261 L22.06158 17.52667 L21.99745 17.69921 L21.92910 17.87013 L21.85657 18.03931 L21.77992 18.20666 L21.69918 18.37208 L21.61441 18.53548 L21.52565 18.69674 L21.43296 18.85577 L21.33640 19.01248 L21.23602 19.16678 L21.13189 19.31856 L21.02406 19.46774 L20.91260 19.61424 L20.79758 19.75795 L20.67907 19.89880 L20.55713 20.03669 L20.43185 20.17155 L20.30330 20.30330 L20.17155 20.43185 L20.03669 20.55713 L19.89880 20.67907 L19.75795 20.79758 L19.61424 20.91260 L19.46774 21.02406 L19.31856 21.13189 L19.16678 21.23602 L19.01248 21.33640 L18.85577 21.43296 L18.69674 21.52565 L18.53548 21.61441 L18.37208 21.69918 L18.20666 21.77992 L18.03931 21.85657 L17.87013 21.92910 L17.69921 21.99745 L17.52667 22.06158 L17.35261 22.12146 L17.17714 22.17705 L17.00035 22.22832 L16.82235 22.27523 L16.64326 22.31777 L16.46318 22.35589 L16.28221 22.38958 L16.10048 22.41882 L15.91808 22.44360 L15.73513 22.46389 L15.55173 22.47968 L15.36801 22.49097 L15.18406 22.49774 L15.00000 22.50000")',
              }}
              aria-hidden="true"
            >
              <path
                class="as-field-resize-hit"
                d="M26.25000 15.00000 L26.24661 15.27609 L26.23645 15.55201 L26.21952 15.82760 L26.19583 16.10269 L26.16539 16.37712 L26.12824 16.65072 L26.08437 16.92332 L26.03383 17.19477 L25.97665 17.46489 L25.91285 17.73353 L25.84248 18.00052 L25.76558 18.26570 L25.68219 18.52892 L25.59237 18.79001 L25.49617 19.04882 L25.39364 19.30519 L25.28486 19.55896 L25.16988 19.80999 L25.04877 20.05813 L24.92161 20.30321 L24.78848 20.54510 L24.64945 20.78366 L24.50460 21.01872 L24.35403 21.25017 L24.19783 21.47784 L24.03608 21.70162 L23.86890 21.92136 L23.69637 22.13692 L23.51860 22.34819 L23.33570 22.55504 L23.14778 22.75733 L22.95495 22.95495 L22.75733 23.14778 L22.55504 23.33570 L22.34819 23.51860 L22.13692 23.69637 L21.92136 23.86890 L21.70162 24.03608 L21.47784 24.19783 L21.25017 24.35403 L21.01872 24.50460 L20.78366 24.64945 L20.54510 24.78848 L20.30321 24.92161 L20.05813 25.04877 L19.80999 25.16988 L19.55896 25.28486 L19.30519 25.39364 L19.04882 25.49617 L18.79001 25.59237 L18.52892 25.68219 L18.26570 25.76558 L18.00052 25.84248 L17.73353 25.91285 L17.46489 25.97665 L17.19477 26.03383 L16.92332 26.08437 L16.65072 26.12824 L16.37712 26.16539 L16.10269 26.19583 L15.82760 26.21952 L15.55201 26.23645 L15.27609 26.24661 L15.00000 26.25000"
              />
              <path d="M26.25000 15.00000 L26.24661 15.27609 L26.23645 15.55201 L26.21952 15.82760 L26.19583 16.10269 L26.16539 16.37712 L26.12824 16.65072 L26.08437 16.92332 L26.03383 17.19477 L25.97665 17.46489 L25.91285 17.73353 L25.84248 18.00052 L25.76558 18.26570 L25.68219 18.52892 L25.59237 18.79001 L25.49617 19.04882 L25.39364 19.30519 L25.28486 19.55896 L25.16988 19.80999 L25.04877 20.05813 L24.92161 20.30321 L24.78848 20.54510 L24.64945 20.78366 L24.50460 21.01872 L24.35403 21.25017 L24.19783 21.47784 L24.03608 21.70162 L23.86890 21.92136 L23.69637 22.13692 L23.51860 22.34819 L23.33570 22.55504 L23.14778 22.75733 L22.95495 22.95495 L22.75733 23.14778 L22.55504 23.33570 L22.34819 23.51860 L22.13692 23.69637 L21.92136 23.86890 L21.70162 24.03608 L21.47784 24.19783 L21.25017 24.35403 L21.01872 24.50460 L20.78366 24.64945 L20.54510 24.78848 L20.30321 24.92161 L20.05813 25.04877 L19.80999 25.16988 L19.55896 25.28486 L19.30519 25.39364 L19.04882 25.49617 L18.79001 25.59237 L18.52892 25.68219 L18.26570 25.76558 L18.00052 25.84248 L17.73353 25.91285 L17.46489 25.97665 L17.19477 26.03383 L16.92332 26.08437 L16.65072 26.12824 L16.37712 26.16539 L16.10269 26.19583 L15.82760 26.21952 L15.55201 26.23645 L15.27609 26.24661 L15.00000 26.25000" />
            </svg>
          )}
        </span>
        {hasMarker &&
          (p.readOnly || p.disabled ? (
            <span className="as-field-readonly-marker" aria-hidden="true">
              <Icon name="pencilOff" weight="bold" />
            </span>
          ) : (
            <span className="as-field-type-marker" data-field-icon={fieldIcon} aria-hidden="true">
              <Icon name={fieldIcon} weight="bold" />
            </span>
          ))}
      </span>
      {(p.error || p.hint) && (
        <span id={p.id + '-description'} className="as-field-description">
          {p.error || p.hint}
        </span>
      )}
    </div>
  );
});
